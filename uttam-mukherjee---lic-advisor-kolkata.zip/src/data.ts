import { ServiceItem, LicPlan } from './types';

export const SERVICES: ServiceItem[] = [
  // Financial Planning Services
  {
    id: 'life-insurance',
    title: 'Life Insurance Planning',
    category: 'financial',
    description: 'Ensure comprehensive financial protection for your family in your absence. Custom life covers tailored to income and liabilities.',
    detailedInfo: 'Life Insurance Planning is the foundation of financial security. We calculate your Human Life Value (HLV) to determine the exact amount of cover your family requires. This protects your loved ones from debt, maintains their lifestyle, and ensures their financial independence.',
    iconName: 'ShieldCheck'
  },
  {
    id: 'child-future',
    title: 'Child Future Planning',
    category: 'financial',
    description: 'Secure funds for your child’s premium higher education and marriage, guaranteed regardless of life’s uncertainties.',
    detailedInfo: 'Our Child Future plans (using LIC’s specialized child policies like Jeevan Lakshya) secure funds for critical milestones like college admission at ages 18, 21, and 25. The plan includes a premium waiver benefit—if anything happens to the parent, all future premiums are waived, and the child still gets the guaranteed maturity.',
    iconName: 'GraduationCap'
  },
  {
    id: 'retirement-planning',
    title: 'Retirement Planning',
    category: 'financial',
    description: 'Create a guaranteed lifelong pension stream to enjoy your sunset years with absolute financial freedom.',
    detailedInfo: 'Retirement Planning involves building an inflation-beating corpus that converts into guaranteed lifetime annuity (pension) streams. Using plans like LIC Jeevan Akshay or Jeevan Shanti, we guarantee a fixed income for life, ensuring you never have to depend on anyone else.',
    iconName: 'Sparkles'
  },
  {
    id: 'tax-saving',
    title: 'Tax Saving Plans (80C)',
    category: 'financial',
    description: 'Maximize your annual tax savings under Section 80C while building long-term wealth with sovereign guarantees.',
    detailedInfo: 'LIC policies offer a triple tax benefit: premium paid is tax-exempt under Section 80C (up to ₹1.5 Lakhs), any annual growth/bonuses are tax-free, and the final maturity amount is completely tax-exempt under Section 10(10D). It remains one of the safest tax-saving instruments in India.',
    iconName: 'PiggyBank'
  },

  // LIC Policy Services
  {
    id: 'policy-loan',
    title: 'Policy Loan Assistance',
    category: 'policy',
    description: 'Need urgent funds? Get low-interest loans against your active LIC policy with minimal paperwork and no collateral.',
    detailedInfo: 'If your policy has accumulated a surrender value (usually after 2 full years of premiums), you are eligible to take a loan of up to 90% of the surrender value. The interest rate is highly competitive (usually around 9-10% simple interest), and you can repay only interest and let the principal adjust against maturity.',
    iconName: 'Coins'
  },
  {
    id: 'policy-surrender',
    title: 'Policy Surrender Support',
    category: 'policy',
    description: 'Professional guidance on surrendering your policy or converting it into a paid-up policy to avoid losses.',
    detailedInfo: 'Surrendering a policy prematurely can lead to financial loss. We help you evaluate whether you should surrender, let the policy become Paid-Up, or apply for a loan instead. If surrendering is the only option, we assist in processing the documentation at the Maula Ali branch.',
    iconName: 'FileText'
  },
  {
    id: 'maturity-claim',
    title: 'Maturity Claim Assistance',
    category: 'policy',
    description: 'Hassle-free settlement and processing of your maturing LIC policies directly to your bank account.',
    detailedInfo: 'When your policy matures, you must submit the Discharge Form (Form 3825), original policy document, NEFT mandate, and KYC. We provide doorstep service to collect, verify, and submit these to the branch to ensure swift payouts without delays.',
    iconName: 'Gift'
  },
  {
    id: 'nomination-change',
    title: 'Nomination Change',
    category: 'policy',
    description: 'Update or change policy nominees to align with changes in your life like marriage or child birth.',
    detailedInfo: 'Keeping your nomination updated is vital. Whether you need to change nominee to a spouse post-marriage, add children, or handle successive nominations, we prepare the required endorsement forms and process the change in LIC systems.',
    iconName: 'UserCheck'
  },
  {
    id: 'policy-revival',
    title: 'Policy Revival Support',
    category: 'policy',
    description: 'Reactivate your lapsed LIC policies. Get advice on health declaration requirements and late fee concessions.',
    detailedInfo: 'If your policy has lapsed due to unpaid premiums, you can revive it within 5 consecutive years from the first unpaid premium. We help you estimate the total premium dues with interest, check for ongoing LIC late fee concession campaigns, and arrange medical reports if needed.',
    iconName: 'RefreshCw'
  },
  {
    id: 'premium-payment',
    title: 'Premium Payment Support',
    category: 'policy',
    description: 'Assistance setting up online auto-payments (NACH), online portals, or processing manual premium receipts.',
    detailedInfo: 'Avoid lapses by setting up NACH auto-debits or using the LIC Customer Portal. We guide you step-by-step to pay premiums safely online, download premium payment certificates for tax filing, and resolve payment failure issues.',
    iconName: 'CreditCard'
  },
  {
    id: 'address-update',
    title: 'Address & Contact Update',
    category: 'policy',
    description: 'Ensure you receive crucial policy notices and maturity updates by keeping your phone and address updated.',
    detailedInfo: 'Many policyholders miss maturity claims because of outdated contact details. We help you submit official change-of-address requests and register your mobile number/email to receive automated SMS alerts for premium dues.',
    iconName: 'MapPin'
  },
  {
    id: 'new-consultation',
    title: 'New Policy Consultation',
    category: 'policy',
    description: 'Schedule a free physical or virtual sitting to discuss customized financial plans suited to your savings goals.',
    detailedInfo: 'Schedule an in-depth consultation. Whether you prefer a meeting at your home in Kolkata, at our Maula Ali office, or over a Zoom call, we analyze your financial goals and present customized proposals with projected returns.',
    iconName: 'PhoneCall'
  }
];

export const LIC_PLANS: LicPlan[] = [
  {
    id: 'jevan-lakshya',
    name: 'LIC Jeevan Lakshya',
    tableNo: 'Table 733',
    category: 'child',
    description: 'The ultimate child future and education protection plan. Provides regular annual income to family in case of parents absence.',
    keyBenefits: [
      'Guaranteed annual income (10% of Sum Assured) to child on parent’s demise',
      'Exemption from paying all future premiums if parent passes away',
      'Full maturity sum assured paid at the end of the term with accrued bonuses',
      'Tax-free maturity under Sec 10(10D)'
    ],
    targetAudience: 'Parents with young kids wanting to secure higher education milestones',
    minAge: 18,
    maxAge: 50,
    premiumFrequency: ['Yearly', 'Half-Yearly', 'Quarterly', 'Monthly (NACH)']
  },
  {
    id: 'jevan-umang',
    name: 'LIC Jeevan Umang',
    tableNo: 'Table 745',
    category: 'retirement',
    description: 'Whole life assurance and pension plan. Provides guaranteed 8% survival benefit every year after premium paying term for life.',
    keyBenefits: [
      'Guaranteed annual survival benefit of 8% of Sum Assured for lifetime',
      'Life cover protection up to 100 years of age',
      'Huge tax-free corpus payout to nominees at age 100 or on prior demise',
      'Excellent tax-free secondary pension stream'
    ],
    targetAudience: 'Individuals seeking a guaranteed lifetime tax-free pension',
    minAge: 0.25, // 90 days
    maxAge: 55,
    premiumFrequency: ['Yearly', 'Half-Yearly', 'Quarterly', 'Monthly (NACH)']
  },
  {
    id: 'jevan-labh',
    name: 'LIC Jeevan Labh',
    tableNo: 'Table 736',
    category: 'endowment',
    description: 'High bonus, limited premium paying endowment plan. Gives the highest maturity returns among standard plans.',
    keyBenefits: [
      'Limited Premium Payment (Pay only 10, 15, or 16 years for terms of 16, 21, or 25 years)',
      'Highest rate of revisionary bonus for rapid corpus accumulation',
      'Combines high saving returns with full financial protection cover',
      'Loan facility available after 2 years'
    ],
    targetAudience: 'Salaried professionals seeking maximum savings and wealth creation',
    minAge: 8,
    maxAge: 59,
    premiumFrequency: ['Yearly', 'Half-Yearly', 'Quarterly', 'Monthly (NACH)']
  },
  {
    id: 'jevan-utsav',
    name: 'LIC Jeevan Utsav',
    tableNo: 'Table 771',
    category: 'retirement',
    description: 'Lifetime guaranteed regular income plan with a limited premium paying term of just 5 to 16 years.',
    keyBenefits: [
      'Guaranteed 10% of Sum Assured paid annually for lifetime after deferment',
      'Options to accumulate income and withdraw later with interest (5.5% compounded)',
      'Short premium paying terms starting from only 5 years',
      'Sovereign lifetime guarantee by Government of India'
    ],
    targetAudience: 'Salaried and self-employed individuals looking for quick retirement guarantees',
    minAge: 0.25,
    maxAge: 65,
    premiumFrequency: ['Yearly', 'Half-Yearly', 'Quarterly', 'Monthly (NACH)']
  },
  {
    id: 'index-plus',
    name: 'LIC Index Plus (Unit Linked)',
    tableNo: 'Table 873',
    category: 'endowment',
    description: 'Market-linked investment plan with guaranteed life cover protection. High potential returns with professional fund management.',
    keyBenefits: [
      'Combined benefit of investment growth and life insurance',
      'Refund of mortality charges at maturity',
      'Flexible fund switching options (Growth, Balanced, Secure)',
      'Completely transparent charges structure'
    ],
    targetAudience: 'Young investors looking for equity market exposure with life cover safety',
    minAge: 90, // days
    maxAge: 65,
    premiumFrequency: ['Yearly', 'Half-Yearly', 'Quarterly', 'Monthly (NACH)']
  },
  {
    id: 'jeevan-amar',
    name: "LIC's New Jeevan Amar (Term Plan)",
    tableNo: 'Table 955',
    category: 'term',
    description: 'Highly affordable high-cover pure term insurance. Ultimate risk safeguard for your family’s standard of living.',
    keyBenefits: [
      'Very low premium rates for massive financial coverage',
      'Special discounted premium rates for female lives and non-smokers',
      'Option to choose between Level Sum Assured and Increasing Sum Assured',
      'Optional Accidental Death Benefit Rider'
    ],
    targetAudience: 'Breadwinners and young professionals with dependents and active loans',
    minAge: 18,
    maxAge: 65,
    premiumFrequency: ['Yearly', 'Half-Yearly']
  }
];

export const TESTIMONIALS = [
  {
    name: 'Siddharth Sen',
    role: 'IT Professional, Salt Lake',
    content: 'Uttam Da is extremely knowledgeable and sincere. He helped me structure my daughter’s educational planning with Jeevan Lakshya. He explained everything transparently and handled the documentation at my home.',
    rating: 5
  },
  {
    name: 'Pranab Mukherjee',
    role: 'Retiree, Garia',
    content: 'For policy maturity and loan, I was facing issue. Uttam Mukherjee helped me resolve it within 3 days. He visited the Maula Ali branch and got it settled directly in my bank. Highly recommended!',
    rating: 5
  },
  {
    name: 'Meenakshi Banerjee',
    role: 'School Teacher, Tollygunge',
    content: 'I took Jeevan Umang plan for lifetime retirement pension. Uttam Babu analyzed my budget and suggested the exact premium term. Very professional and always available on call.',
    rating: 5
  }
];

export const FAQS = [
  {
    question: 'Where is your branch office in Kolkata?',
    answer: 'Our official branch office is LIC City Branch 11, located at 73, Lenin Sarani Rd, Maula Ali, Taltala, Kolkata, West Bengal 700013. We support clients all over Kolkata, Howrah, and nearby regions.'
  },
  {
    question: 'Can I pay my premiums online directly, and will you help me set it up?',
    answer: 'Yes! We encourage online payments to avoid delays. We help you set up NACH auto-debit, install the LIC Customer app, or guide you through the secure online portal. It is completely free of charge.'
  },
  {
    question: 'What is the Child Future Plan (Jeevan Lakshya) Premium Waiver Benefit?',
    answer: 'Premium Waiver Benefit (PWB) is a crucial rider. If the parent (proposer) dies, all remaining future premiums of the child policy are completely waived. LIC pays 10% of the sum assured to the child every year, and on maturity, the child receives the full guaranteed sum plus bonuses.'
  },
  {
    question: 'What documents are required to claim policy maturity or survival benefits?',
    answer: 'Generally, you need the original policy bond, Discharge Form (Form 3825), a canceled check or bank passbook copy, NEFT mandate, and KYC documents (Aadhaar & PAN). We collect these from your doorstep and submit them safely.'
  },
  {
    question: 'How do I take a loan against my active LIC policy?',
    answer: 'Any LIC policy that has completed at least 2 full years and has surrender value can be used to procure a loan. You can get up to 90% of the surrender value as an instant loan. The rate is about 9-10% simple interest, which is much cheaper than bank personal loans.'
  }
];
