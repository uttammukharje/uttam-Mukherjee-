export interface LeadInquiry {
  id: string;
  name: string;
  phone: string;
  email?: string;
  serviceType: string;
  message: string;
  status: 'new' | 'contacted' | 'in_progress' | 'closed';
  createdAt: string;
  notes?: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  category: 'financial' | 'policy';
  description: string;
  detailedInfo: string;
  iconName: string;
}

export interface LicPlan {
  id: string;
  name: string;
  tableNo: string;
  category: 'endowment' | 'moneyback' | 'term' | 'retirement' | 'child';
  description: string;
  keyBenefits: string[];
  targetAudience: string;
  minAge: number;
  maxAge: number;
  premiumFrequency: string[];
}
