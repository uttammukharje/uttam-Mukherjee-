import React from 'react';
import { Shield, MapPin, Mail, Phone, Calendar, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export default function Footer({ setActiveTab }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const handleLinkClick = (tabId: string) => {
    setActiveTab(tabId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="main-footer" className="bg-slate-900 text-slate-300 pt-16 pb-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-slate-800">
          {/* Column 1: Brand & Bio */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center space-x-2.5">
              <div className="bg-gradient-to-br from-yellow-400 to-amber-500 p-2 rounded-lg text-blue-950 shadow-md">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-display font-bold text-white leading-tight">Uttam Mukherjee</h3>
                <p className="text-[11px] uppercase tracking-wider text-blue-400 font-semibold">LIC Certified Consultant</p>
              </div>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              Serving families and individuals across Kolkata and Howrah with professional life insurance planning, claim settlements, and custom retirement/child plans.
            </p>
            <div className="pt-2 text-xs text-slate-500">
              <p>Branch Code: City BR 11 (Kolkata)</p>
              <p>Certified Agency ID: 03177724 / West Bengal IRDAI</p>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="md:col-span-2 space-y-4">
            <h4 className="font-display font-semibold text-white text-sm uppercase tracking-wider">Quick Navigation</h4>
            <ul className="space-y-2.5 text-sm">
              {['home', 'about', 'services', 'plans', 'contact'].map((tab) => (
                <li key={tab}>
                  <button
                    onClick={() => handleLinkClick(tab)}
                    className="hover:text-blue-400 transition-colors capitalize flex items-center group text-left"
                  >
                    <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2 opacity-0 group-hover:opacity-100 transition-opacity"></span>
                    {tab === 'about' ? 'About Me' : tab === 'plans' ? 'LIC Plans' : tab}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Policy Assistance Quick List */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="font-display font-semibold text-white text-sm uppercase tracking-wider">LIC Support Links</h4>
            <ul className="space-y-2.5 text-sm text-slate-400">
              <li>
                <button onClick={() => handleLinkClick('services')} className="hover:text-blue-400 transition-colors flex items-center">
                  <ArrowUpRight className="w-3.5 h-3.5 mr-1 text-yellow-400" /> Policy Loan Support
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('services')} className="hover:text-blue-400 transition-colors flex items-center">
                  <ArrowUpRight className="w-3.5 h-3.5 mr-1 text-yellow-400" /> Maturity Claim Help
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('services')} className="hover:text-blue-400 transition-colors flex items-center">
                  <ArrowUpRight className="w-3.5 h-3.5 mr-1 text-yellow-400" /> Policy Revival (Lapsed)
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('services')} className="hover:text-blue-400 transition-colors flex items-center">
                  <ArrowUpRight className="w-3.5 h-3.5 mr-1 text-yellow-400" /> Nomination Corrections
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Main Office Details */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="font-display font-semibold text-white text-sm uppercase tracking-wider">Branch Address</h4>
            <ul className="space-y-3.5 text-sm text-slate-400">
              <li className="flex items-start">
                <MapPin className="w-4 h-4 mr-2.5 text-blue-400 shrink-0 mt-1" />
                <span className="leading-relaxed">
                  73, Lenin Sarani Rd, Maula Ali, Taltala, Kolkata, West Bengal 700013
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="w-4 h-4 mr-2.5 text-blue-400 shrink-0" />
                <a href="tel:+917439001214" className="hover:text-blue-400 transition-colors">
                  +91 74390 01214
                </a>
              </li>
              <li className="flex items-center">
                <Mail className="w-4 h-4 mr-2.5 text-blue-400 shrink-0" />
                <a href="mailto:uttammukhopadhyay777@gmail.com" className="hover:text-blue-400 transition-colors break-all">
                  uttammukhopadhyay777@gmail.com
                </a>
              </li>
              <li className="flex items-center">
                <Calendar className="w-4 h-4 mr-2.5 text-blue-400 shrink-0" />
                <span>Mon - Sat: 10:00 AM - 07:00 PM</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Disclaimer section & copyright */}
        <div className="pt-8 space-y-4">
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs text-slate-500 leading-relaxed text-center md:text-left">
            <span className="font-semibold text-slate-400 uppercase tracking-wider block mb-1">Disclaimer & Regulatory Notice:</span>
            Insurance is the subject matter of solicitation. The information provided on this website is for informational and educational purposes only. All investment calculations, plan maturity projections, and benefits shown are indicative based on LIC of India’s current rates, underwriting criteria, and policy guidelines, which are subject to changes by LIC of India. Uttam Mukherjee is an independent certified advisor registered under Life Insurance Corporation of India (LIC).
          </div>
          <div className="flex flex-col md:flex-row justify-between items-center text-xs text-slate-500">
            <p>© {currentYear} Uttam Mukherjee – LIC Consultant, Kolkata. All Rights Reserved.</p>
            <p className="mt-2 md:mt-0">
              Securely developed & optimized for Kolkata insurance queries.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
