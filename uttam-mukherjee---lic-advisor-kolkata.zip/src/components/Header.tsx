import React, { useState, useEffect } from 'react';
import { Menu, X, Shield, Phone, MessageSquare, Lock } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Header({ activeTab, setActiveTab }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Me' },
    { id: 'services', label: 'Services' },
    { id: 'plans', label: 'LIC Plans' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setIsOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header
      id="main-header"
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-md shadow-md py-3'
          : 'bg-gradient-to-r from-blue-900 to-indigo-950 text-white py-4'
      }`}
    >
      {/* Top micro-bar when not scrolled */}
      {!scrolled && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 hidden sm:flex justify-between items-center text-xs pb-2 border-b border-white/10 mb-2">
          <div className="flex items-center space-x-4">
            <span className="flex items-center text-blue-200">
              <Shield className="w-3.5 h-3.5 mr-1" />
              LIC Certified Advisor (Office Code: City BR 11)
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <a href="tel:+917439001214" className="flex items-center hover:text-blue-300 transition-colors">
              <Phone className="w-3.5 h-3.5 mr-1 text-yellow-400" />
              +91 7439001214
            </a>
            <a
              href="https://wa.me/917439001214?text=Hi%20Uttam%20Ji%2C%20I%20visited%20your%20website%20and%20need%20LIC%20service%20consultation."
              target="_blank"
              rel="noreferrer"
              className="flex items-center text-emerald-400 hover:text-emerald-300 transition-colors"
            >
              <MessageSquare className="w-3.5 h-3.5 mr-1" />
              WhatsApp Support
            </a>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Brand Logo */}
          <div
            id="brand-logo"
            onClick={() => handleNavClick('home')}
            className="flex items-center space-x-2.5 cursor-pointer group"
          >
            <div className="bg-gradient-to-br from-yellow-400 to-amber-500 p-2 rounded-lg text-blue-900 shadow-md group-hover:scale-105 transition-transform duration-200">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h1 className={`font-display font-bold leading-tight ${scrolled ? 'text-blue-900' : 'text-white'}`}>
                Uttam Mukherjee
              </h1>
              <p className={`text-[10px] font-sans font-medium tracking-wider uppercase ${scrolled ? 'text-gray-500' : 'text-blue-200'}`}>
                LIC Consultant & Financial Advisor
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                id={`nav-link-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`px-4 py-2 rounded-full font-sans text-sm font-medium transition-all duration-200 ${
                  activeTab === item.id
                    ? scrolled
                      ? 'bg-blue-900 text-white shadow-sm'
                      : 'bg-white text-blue-900 shadow-md'
                    : scrolled
                    ? 'text-gray-600 hover:text-blue-900 hover:bg-gray-100'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                {item.label}
              </button>
            ))}

            {/* Admin Dashboard Entry */}
            <button
              id="nav-link-admin"
              onClick={() => handleNavClick('admin')}
              className={`ml-2 p-2 rounded-full flex items-center justify-center transition-all ${
                activeTab === 'admin'
                  ? scrolled
                    ? 'bg-blue-100 text-blue-900'
                    : 'bg-white/20 text-yellow-400'
                  : scrolled
                  ? 'text-gray-400 hover:text-blue-900 hover:bg-gray-100'
                  : 'text-white/60 hover:text-white hover:bg-white/10'
              }`}
              title="Admin Lead Panel"
            >
              <Lock className="w-4 h-4" />
            </button>
          </nav>

          {/* Mobile menu button */}
          <div className="flex items-center space-x-2 md:hidden">
            <button
              onClick={() => handleNavClick('admin')}
              className={`p-2 rounded-lg ${scrolled ? 'text-gray-500' : 'text-white/80'}`}
              title="Admin Dashboard"
            >
              <Lock className="w-5 h-5" />
            </button>
            <button
              id="mobile-menu-btn"
              onClick={() => setIsOpen(!isOpen)}
              className={`p-2 rounded-lg focus:outline-none ${
                scrolled ? 'text-blue-900 hover:bg-gray-100' : 'text-white hover:bg-white/10'
              }`}
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div
          id="mobile-drawer"
          className="md:hidden bg-white text-gray-800 border-t border-gray-100 mt-3 shadow-xl animate-in slide-in-from-top duration-200"
        >
          <div className="px-4 pt-2 pb-4 space-y-1.5">
            {navItems.map((item) => (
              <button
                key={item.id}
                id={`mobile-nav-link-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`w-full text-left px-4 py-3 rounded-lg font-sans text-base font-medium transition-all ${
                  activeTab === item.id
                    ? 'bg-blue-900 text-white shadow-md'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-blue-900'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              id="mobile-nav-link-admin"
              onClick={() => handleNavClick('admin')}
              className={`w-full text-left px-4 py-3 rounded-lg font-sans text-base font-medium flex items-center justify-between transition-all ${
                activeTab === 'admin'
                  ? 'bg-blue-900 text-white shadow-md'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-blue-900'
              }`}
            >
              <span>Lead Administrator Panel</span>
              <Lock className="w-4 h-4" />
            </button>

            {/* Quick Contact buttons in mobile drawer */}
            <div className="pt-4 grid grid-cols-2 gap-2 border-t border-gray-100">
              <a
                href="tel:+917439001214"
                className="flex items-center justify-center px-4 py-2.5 rounded-lg bg-blue-50 text-blue-950 text-sm font-semibold border border-blue-100 hover:bg-blue-100"
              >
                <Phone className="w-4 h-4 mr-1.5 text-blue-900" />
                Call Advisor
              </a>
              <a
                href="https://wa.me/917439001214?text=Hi%20Uttam%20Ji%2C%20I%20visited%20your%20website%20and%20need%20LIC%20service%20consultation."
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center px-4 py-2.5 rounded-lg bg-emerald-50 text-emerald-950 text-sm font-semibold border border-emerald-100 hover:bg-emerald-100"
              >
                <MessageSquare className="w-4 h-4 mr-1.5 text-emerald-600" />
                WhatsApp
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
