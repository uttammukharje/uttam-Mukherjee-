import React, { useState } from 'react';
import { HelpCircle, ChevronRight, ChevronLeft, ShieldCheck, DollarSign, User, Calendar, Award, Sparkles, MessageSquare } from 'lucide-react';
import { LIC_PLANS } from '../data';
import { LicPlan } from '../types';

interface PlanAssistantProps {
  onPlanSelected: (serviceName: string, notes: string) => void;
}

export default function PlanAssistant({ onPlanSelected }: PlanAssistantProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    targetPerson: 'self', // self, child, spouse, parents
    primaryGoal: 'retirement', // wealth, child-future, retirement, tax, high-cover
    insuredAge: 30,
    monthlyBudget: 3000,
  });

  const [matchedPlan, setMatchedPlan] = useState<LicPlan | null>(null);
  const [maturityEstimate, setMaturityEstimate] = useState<number | null>(null);

  const nextStep = () => setStep((s) => Math.min(s + 1, 4));
  const prevStep = () => setStep((s) => Math.max(s - 1, 1));

  const calculateRecommendation = () => {
    let matched: LicPlan | undefined;

    // Match logic based on user answers
    if (formData.primaryGoal === 'child-future' || formData.targetPerson === 'child') {
      matched = LIC_PLANS.find((p) => p.id === 'jevan-lakshya');
    } else if (formData.primaryGoal === 'retirement') {
      // Younger people get Jeevan Umang, older or quick pension seekers get Jeevan Utsav
      matched = formData.insuredAge < 40 
        ? LIC_PLANS.find((p) => p.id === 'jevan-umang')
        : LIC_PLANS.find((p) => p.id === 'jevan-utsav');
    } else if (formData.primaryGoal === 'high-cover') {
      matched = LIC_PLANS.find((p) => p.id === 'jeevan-amar');
    } else if (formData.primaryGoal === 'tax' && formData.insuredAge < 35) {
      matched = LIC_PLANS.find((p) => p.id === 'index-plus') || LIC_PLANS.find((p) => p.id === 'jevan-labh');
    } else {
      matched = LIC_PLANS.find((p) => p.id === 'jevan-labh');
    }

    if (!matched) matched = LIC_PLANS[0];

    setMatchedPlan(matched);

    // Dynamic, premium projection formulas (indicative simulation for high-fidelity interactive feel)
    // Maturity value is modeled based on policy structure and standard LIC bonus rates
    const annualPremium = formData.monthlyBudget * 12;
    let tenure = 21; // standard tenure estimate
    let benefitMultiplier = 1.95; // default endowment multiplier

    if (matched.id === 'jevan-labh') {
      tenure = 25;
      benefitMultiplier = 2.4; // Jeevan Labh has highest bonus rates
    } else if (matched.id === 'jevan-umang') {
      tenure = 100 - formData.insuredAge;
      benefitMultiplier = 3.2; // Jeevan Umang is whole life
    } else if (matched.id === 'jevan-lakshya') {
      tenure = 21;
      benefitMultiplier = 2.0;
    } else if (matched.id === 'jeevan-amar') {
      tenure = 30;
      benefitMultiplier = 0; // Term cover has no maturity, high coverage instead!
    }

    const totalInvested = annualPremium * (matched.id === 'jevan-labh' ? 16 : 15); // limited premium
    const estimatedMaturity = benefitMultiplier > 0 ? totalInvested * benefitMultiplier : 0;

    setMaturityEstimate(Math.round(estimatedMaturity));
    setStep(5); // Show recommendation result screen
  };

  const handleStartOver = () => {
    setStep(1);
    setMatchedPlan(null);
    setMaturityEstimate(null);
  };

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(num);
  };

  const handleConsult = () => {
    if (!matchedPlan) return;
    const details = `Matched Plan: ${matchedPlan.name} (${matchedPlan.tableNo}). Insured Age: ${formData.insuredAge}, Planned Monthly Savings: ${formatCurrency(formData.monthlyBudget)}. Target Milestone: ${formData.primaryGoal}.`;
    onPlanSelected(matchedPlan.name, details);
  };

  return (
    <div id="plan-assistant-wizard" className="bg-gradient-to-br from-blue-50 to-indigo-50/50 rounded-2xl border border-blue-100/50 p-6 sm:p-8 shadow-sm">
      <div className="max-w-2xl mx-auto">
        
        {/* Wizard Header */}
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-blue-600 text-white p-2.5 rounded-xl shadow-md shrink-0">
            <Sparkles className="w-5 h-5 text-yellow-300" />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg sm:text-xl text-blue-950">AI-Powered LIC Plan Matcher</h3>
            <p className="text-xs sm:text-sm text-slate-600">Find the perfect policy based on your milestones, age & savings goal.</p>
          </div>
        </div>

        {/* Step Progress Indicators */}
        {step <= 4 && (
          <div className="mb-8 flex items-center justify-between text-xs text-slate-400 font-semibold px-1">
            <span className={step >= 1 ? 'text-blue-800' : ''}>1. Beneficiary</span>
            <ChevronRight className="w-3 h-3" />
            <span className={step >= 2 ? 'text-blue-800' : ''}>2. Milestone</span>
            <ChevronRight className="w-3 h-3" />
            <span className={step >= 3 ? 'text-blue-800' : ''}>3. Insured Age</span>
            <ChevronRight className="w-3 h-3" />
            <span className={step >= 4 ? 'text-blue-800' : ''}>4. Budget</span>
          </div>
        )}

        {/* Step 1: Beneficiary */}
        {step === 1 && (
          <div className="space-y-5 animate-in fade-in duration-200">
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-900 flex items-center gap-1.5">
                <User className="w-4 h-4 text-blue-800" />
                Who are you looking to secure under this LIC policy?
              </label>
              <p className="text-xs text-slate-500">Different plans cater to children, working parents, or elderly dependencies.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { id: 'self', label: 'Myself (Main Breadwinner)', desc: 'Secure income & tax benefits' },
                { id: 'child', label: 'My Son / Daughter', desc: 'Secure education & marriage corpus' },
                { id: 'spouse', label: 'My Spouse (Husband/Wife)', desc: 'Secondary life cover & pension' },
                { id: 'parents', label: 'My Retired Parents', desc: 'Sovereign lifetime annuity cover' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setFormData({ ...formData, targetPerson: item.id })}
                  className={`p-4 text-left rounded-xl border transition-all cursor-pointer ${
                    formData.targetPerson === item.id
                      ? 'bg-blue-900/5 border-blue-800 text-blue-950 ring-1 ring-blue-800/20'
                      : 'bg-white border-gray-200 text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <p className="font-semibold text-sm">{item.label}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{item.desc}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Milestone/Goal */}
        {step === 2 && (
          <div className="space-y-5 animate-in fade-in duration-200">
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-900 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-blue-800" />
                What is your primary financial goal?
              </label>
              <p className="text-xs text-slate-500">Every plan has distinct savings structures: high survival, high death cover, or high maturity bonuses.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { id: 'retirement', label: 'Guaranteed Lifetime Pension', desc: 'Fixed monthly pension in retired years' },
                { id: 'child-future', label: 'Child Education & Milestones', desc: 'Premium waiver safety and timed payouts' },
                { id: 'wealth', label: 'Wealth Savings & Growth', desc: 'Maximizing returns with limited tenure options' },
                { id: 'tax', label: 'Tax Saving (80C) Benefits', desc: 'Zero tax on returns + full Section 80C exemptions' },
                { id: 'high-cover', label: 'Pure High-Cover Risk Protection', desc: 'Massive financial security at lowest cost' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setFormData({ ...formData, primaryGoal: item.id })}
                  className={`p-4 text-left rounded-xl border transition-all cursor-pointer ${
                    formData.primaryGoal === item.id
                      ? 'bg-blue-900/5 border-blue-800 text-blue-950 ring-1 ring-blue-800/20'
                      : 'bg-white border-gray-200 text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <p className="font-semibold text-sm">{item.label}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{item.desc}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 3: Insured Age */}
        {step === 3 && (
          <div className="space-y-5 animate-in fade-in duration-200">
            <div className="space-y-1">
              <label htmlFor="insuredAge" className="text-sm font-semibold text-slate-900 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-blue-800" />
                What is the current age of the insured person?
              </label>
              <p className="text-xs text-slate-500">Age governs the minimum premium rates, maximum risk coverage, and policy tenure eligibility.</p>
            </div>
            <div className="bg-white p-6 rounded-xl border border-gray-100 flex flex-col items-center space-y-4">
              <span className="text-3xl font-display font-bold text-blue-950">{formData.insuredAge} <span className="text-lg font-sans text-gray-500">Years Old</span></span>
              <input
                type="range"
                id="insuredAge"
                min="1"
                max="65"
                value={formData.insuredAge}
                onChange={(e) => setFormData({ ...formData, insuredAge: parseInt(e.target.value) })}
                className="w-full h-2 bg-blue-100 rounded-lg appearance-none cursor-pointer accent-blue-900"
              />
              <div className="w-full flex justify-between text-xs text-gray-400 font-semibold px-1">
                <span>Min: 1 Year</span>
                <span>Max: 65 Years</span>
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Budget */}
        {step === 4 && (
          <div className="space-y-5 animate-in fade-in duration-200">
            <div className="space-y-1">
              <label htmlFor="monthlyBudget" className="text-sm font-semibold text-slate-900 flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-blue-800" />
                What is your comfortable monthly savings budget?
              </label>
              <p className="text-xs text-slate-500">Select a budget you can consistently save for 10-15 years. Premiums are payable yearly/half-yearly or via easy monthly NACH auto-debits.</p>
            </div>
            <div className="bg-white p-6 rounded-xl border border-gray-100 flex flex-col items-center space-y-4">
              <span className="text-3xl font-display font-bold text-blue-950">{formatCurrency(formData.monthlyBudget)} <span className="text-sm font-sans text-gray-500">/ Month</span></span>
              <input
                type="range"
                id="monthlyBudget"
                min="1000"
                max="25000"
                step="500"
                value={formData.monthlyBudget}
                onChange={(e) => setFormData({ ...formData, monthlyBudget: parseInt(e.target.value) })}
                className="w-full h-2 bg-blue-100 rounded-lg appearance-none cursor-pointer accent-blue-900"
              />
              <div className="w-full flex justify-between text-xs text-gray-400 font-semibold px-1">
                <span>₹1,000 / month</span>
                <span>₹25,000 / month</span>
              </div>
            </div>
          </div>
        )}

        {/* Step 5: Recommendation Screen */}
        {step === 5 && matchedPlan && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div className="bg-gradient-to-r from-blue-900 to-indigo-950 p-6 rounded-xl text-white border border-blue-950 relative overflow-hidden shadow-md">
              {/* Decorative radial overlay */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-400/10 rounded-full blur-2xl"></div>
              
              <span className="inline-flex items-center px-2.5 py-0.5 bg-yellow-400 text-blue-950 text-[10px] font-bold rounded-full uppercase tracking-wider mb-2 shadow-sm">
                Recommended Policy Match
              </span>
              <h4 className="font-display font-bold text-2xl text-white">{matchedPlan.name}</h4>
              <p className="text-xs font-semibold text-blue-200 mt-0.5">Official Code: {matchedPlan.tableNo} (Sovereign Guaranteed by Govt of India)</p>
              
              <p className="text-sm text-blue-100/90 leading-relaxed mt-3 pt-3 border-t border-white/10">
                {matchedPlan.description}
              </p>
            </div>

            {/* Calculations Panel */}
            <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-0.5 border-b sm:border-b-0 sm:border-r border-gray-100 pb-3 sm:pb-0 sm:pr-4">
                <span className="text-xs text-gray-500 font-semibold uppercase tracking-wider block">Insured Profile & Budget</span>
                <p className="text-slate-800 font-bold text-sm mt-1">Age: {formData.insuredAge} Years</p>
                <p className="text-slate-800 font-bold text-sm">Target Milestone: <span className="capitalize text-blue-800">{formData.primaryGoal.replace('-', ' ')}</span></p>
                <p className="text-slate-800 font-bold text-sm">Indicative Savings: {formatCurrency(formData.monthlyBudget)} / month</p>
              </div>

              <div className="space-y-0.5">
                <span className="text-xs text-gray-500 font-semibold uppercase tracking-wider block">Estimated Payouts</span>
                {matchedPlan.id === 'jeevan-amar' ? (
                  <div className="mt-1">
                    <p className="text-xl font-bold text-red-600">Pure Term Cover</p>
                    <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                      This is a high-liability term cover. Provides immediate safety fund of up to 100x premiums paid to your family if any event occurs.
                    </p>
                  </div>
                ) : (
                  <div className="mt-1">
                    <p className="text-2xl font-display font-bold text-emerald-600">{formatCurrency(maturityEstimate || 0)}</p>
                    <p className="text-[10px] text-gray-400 italic">
                      *Estimated maturity payout including accrued bonus & loyalty additions under standard conditions. Tax-Free under Sec 10(10D).
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Key benefits list */}
            <div className="space-y-2">
              <h5 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Key Policy Highlights:</h5>
              <ul className="space-y-2">
                {matchedPlan.keyBenefits.map((benefit, i) => (
                  <li key={i} className="flex items-start text-xs sm:text-sm text-slate-600">
                    <ShieldCheck className="w-4.5 h-4.5 text-blue-800 shrink-0 mr-2 mt-0.5" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* Action Controls */}
        <div className="mt-8 pt-4 border-t border-gray-200/60 flex justify-between items-center">
          {step > 1 && step <= 4 && (
            <button
              onClick={prevStep}
              className="flex items-center gap-1 px-4 py-2 text-sm font-semibold text-gray-600 hover:text-blue-900 transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
              Back
            </button>
          )}

          {step < 4 ? (
            <button
              onClick={nextStep}
              className="ml-auto flex items-center gap-1 px-5 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-950 text-white text-sm font-semibold shadow-sm transition-all cursor-pointer"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : step === 4 ? (
            <button
              onClick={calculateRecommendation}
              className="ml-auto flex items-center gap-1.5 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-800 to-indigo-900 hover:from-blue-900 hover:to-indigo-950 text-white text-sm font-bold shadow-md transition-all cursor-pointer"
            >
              <Sparkles className="w-4.5 h-4.5 text-yellow-300" />
              Calculate My Matching Plan
            </button>
          ) : (
            <div className="flex gap-3 w-full justify-between items-center">
              <button
                onClick={handleStartOver}
                className="px-4 py-2.5 rounded-xl border border-gray-200 hover:bg-gray-50 text-gray-600 text-xs sm:text-sm font-semibold transition-all cursor-pointer"
              >
                Reset & Re-calculate
              </button>
              <button
                onClick={handleConsult}
                className="flex items-center gap-2 py-3 px-5 sm:px-6 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold shadow-md transition-all cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                Discuss Quote on WhatsApp
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
