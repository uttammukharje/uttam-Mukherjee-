import React, { useState } from 'react';
import { Send, Phone, MessageSquare, CheckCircle2, User, Mail, Sparkles, HelpCircle } from 'lucide-react';
import { LeadInquiry } from '../types';
import { saveLead } from '../lib/leadsStorage';

interface ContactFormProps {
  prefilledService?: string;
  onSuccess?: (inquiry: LeadInquiry) => void;
}

export default function ContactForm({ prefilledService = '', onSuccess }: ContactFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    serviceType: prefilledService || 'New Policy Consultation',
    message: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submittedLead, setSubmittedLead] = useState<LeadInquiry | null>(null);

  const servicesList = [
    'New Policy Consultation',
    'Life Insurance Planning',
    'Child Future Plan',
    'Retirement Planning',
    'Tax Saving Plans (80C)',
    'Policy Loan Assistance',
    'Policy Surrender Support',
    'Maturity Claim Assistance',
    'Nomination Change',
    'Policy Revival Support',
    'Premium Payment Support',
    'Address / Contact Update',
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) {
      alert('Please fill in your name and mobile number.');
      return;
    }

    setLoading(true);

    const newLead: LeadInquiry = {
      id: 'lead_' + Math.random().toString(36).substring(2, 9),
      name: formData.name,
      phone: formData.phone,
      email: formData.email,
      serviceType: formData.serviceType,
      message: formData.message,
      status: 'new',
      createdAt: new Date().toISOString(),
      notes: '',
    };

    // Save lead through our synchronized storage layer (LocalStorage + remote Firestore)
    await saveLead(newLead);

    setSubmittedLead(newLead);
    setIsSubmitted(true);
    setLoading(false);

    if (onSuccess) {
      onSuccess(newLead);
    }
  };

  // Generate WhatsApp text with proper URL encoding
  const getWhatsAppLink = () => {
    if (!submittedLead) return '';
    const text = `Hi Uttam Ji, my name is *${submittedLead.name}*. I visited your website and need your assistance with: *${submittedLead.serviceType}*.
    
📞 *My Phone:* ${submittedLead.phone}
✉️ *My Email:* ${submittedLead.email || 'N/A'}
💬 *My Query:* ${submittedLead.message || 'I would like to have a free consultation.'}`;

    return `https://wa.me/917439001214?text=${encodeURIComponent(text)}`;
  };

  return (
    <div id="contact-form-container" className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden h-full flex flex-col">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-800 to-indigo-900 p-6 text-white text-center sm:text-left">
        <h3 className="font-display font-bold text-xl sm:text-2xl flex items-center justify-center sm:justify-start gap-2">
          <Sparkles className="w-5 h-5 text-yellow-400 shrink-0" />
          Request Free Consultation
        </h3>
        <p className="text-blue-200 text-xs sm:text-sm mt-1">
          Provide your details and Uttam Mukherjee will connect with you within 24 hours.
        </p>
      </div>

      {/* Main body of form or thank you state */}
      <div className="p-6 sm:p-8 flex-grow flex flex-col justify-center">
        {!isSubmitted ? (
          <form id="consultation-form" onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5 flex items-center">
                <User className="w-3.5 h-3.5 mr-1 text-blue-800" /> Full Name <span className="text-red-500 ml-0.5">*</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                required
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter your full name"
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-800 focus:bg-white transition-all text-sm text-gray-900"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="phone" className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5 flex items-center">
                  <Phone className="w-3.5 h-3.5 mr-1 text-blue-800" /> Phone Number <span className="text-red-500 ml-0.5">*</span>
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  required
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="e.g. +91 9876543210"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-800 focus:bg-white transition-all text-sm text-gray-900"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5 flex items-center">
                  <Mail className="w-3.5 h-3.5 mr-1 text-blue-800" /> Email Address <span className="text-gray-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="e.g. name@domain.com"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-800 focus:bg-white transition-all text-sm text-gray-900"
                />
              </div>
            </div>

            <div>
              <label htmlFor="serviceType" className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5 flex items-center">
                <HelpCircle className="w-3.5 h-3.5 mr-1 text-blue-800" /> Required Service <span className="text-red-500 ml-0.5">*</span>
              </label>
              <select
                id="serviceType"
                name="serviceType"
                value={formData.serviceType}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-800 focus:bg-white transition-all text-sm text-gray-900 appearance-none cursor-pointer"
              >
                {servicesList.map((service) => (
                  <option key={service} value={service}>
                    {service}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="message" className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">
                Brief Requirements / Message <span className="text-gray-400 font-normal">(Optional)</span>
              </label>
              <textarea
                id="message"
                name="message"
                rows={3}
                value={formData.message}
                onChange={handleChange}
                placeholder="Share any specific goals or policy issues..."
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-800 focus:bg-white transition-all text-sm text-gray-900"
              ></textarea>
            </div>

            <button
              type="submit"
              id="submit-form-button"
              disabled={loading}
              className="w-full mt-2 py-3.5 px-6 rounded-xl bg-gradient-to-r from-blue-800 to-indigo-900 text-white font-sans font-semibold text-sm shadow-md hover:from-blue-900 hover:to-indigo-950 transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-800 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Submitting Request...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Submit Consultation Request
                </>
              )}
            </button>
          </form>
        ) : (
          <div id="thank-you-card" className="text-center py-6 space-y-6 animate-in fade-in duration-300">
            <div className="mx-auto bg-green-50 text-green-600 p-4 rounded-full w-16 h-16 flex items-center justify-center border border-green-100 shadow-sm">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h4 className="font-display font-bold text-2xl text-slate-900">Thank You, {formData.name}!</h4>
              <p className="text-sm text-slate-600 max-w-md mx-auto">
                Your consultation request has been securely registered in our system. Uttam Ji will contact you shortly at <span className="font-semibold text-slate-900">{formData.phone}</span>.
              </p>
            </div>

            <div className="p-4 bg-blue-50/50 border border-blue-100/80 rounded-xl max-w-md mx-auto">
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-950 block mb-1">Double Touchpoint Guarantee:</span>
              <p className="text-xs text-blue-900 leading-relaxed">
                Connect instantly on WhatsApp right now to bypass wait times and send this pre-filled request directly to Uttam Babu's mobile!
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto pt-2">
              <a
                href={getWhatsAppLink()}
                target="_blank"
                rel="noreferrer"
                className="flex-1 flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-sans font-semibold text-sm shadow-md transition-all cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                Instant WhatsApp Chat
              </a>
              <button
                onClick={() => {
                  setIsSubmitted(false);
                  setFormData({
                    name: '',
                    phone: '',
                    email: '',
                    serviceType: prefilledService || 'New Policy Consultation',
                    message: '',
                  });
                }}
                className="flex-1 py-3 px-5 rounded-xl border border-gray-200 hover:bg-gray-50 text-gray-700 font-sans font-semibold text-sm transition-all cursor-pointer"
              >
                Submit New Query
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
