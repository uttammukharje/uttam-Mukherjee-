import React, { useState, useEffect } from 'react';
import { 
  Search, Filter, ShieldAlert, CheckCircle, Clock, Trash2, ArrowUpDown, 
  UserPlus, PhoneCall, RefreshCw, BarChart3, ChevronRight, FileSpreadsheet,
  Lock, Unlock, Eye, EyeOff, Key, ShieldCheck
} from 'lucide-react';
import { LeadInquiry } from '../types';
import { fetchLeads, updateLead, deleteLeadRecord, resetWithSampleData } from '../lib/leadsStorage';

export default function AdminDashboard() {
  const [leads, setLeads] = useState<LeadInquiry[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [noteText, setNoteText] = useState('');

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('crm_authenticated') === 'true';
  });
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Firebase Sync State
  const [isLoading, setIsLoading] = useState(false);
  const [syncSource, setSyncSource] = useState<'firestore' | 'localStorage'>('localStorage');
  const [syncError, setSyncError] = useState<string | null>(null);

  useEffect(() => {
    if (isAuthenticated) {
      loadLeads();
    }
  }, [isAuthenticated]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPassword = passwordInput.trim();
    if (
      cleanPassword === 'uttam@1214' || 
      cleanPassword === 'admin123' || 
      cleanPassword === 'uttam1214' ||
      cleanPassword === 'uttam'
    ) {
      setIsAuthenticated(true);
      sessionStorage.setItem('crm_authenticated', 'true');
      setAuthError(null);
    } else {
      setAuthError('Incorrect password. Please verify the password and try again.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('crm_authenticated');
    setPasswordInput('');
    setAuthError(null);
  };

  const loadLeads = async () => {
    setIsLoading(true);
    setSyncError(null);
    const result = await fetchLeads();
    setLeads(result.leads);
    setSyncSource(result.source);
    if (result.error) {
      setSyncError(result.error);
    }
    setIsLoading(false);
  };

  const updateLeadStatus = async (id: string, newStatus: LeadInquiry['status']) => {
    // Optimistic UI update
    const updated = leads.map((l) => {
      if (l.id === id) {
        return { ...l, status: newStatus };
      }
      return l;
    });
    setLeads(updated);

    // Sync to Firestore
    const result = await updateLead(id, { status: newStatus });
    if (!result.success && result.error) {
      setSyncError(`Failed to update status in cloud: ${result.error}`);
    }
  };

  const deleteLead = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this lead? This action is irreversible.')) {
      // Optimistic UI update
      const updated = leads.filter((l) => l.id !== id);
      setLeads(updated);

      // Sync to Firestore
      const result = await deleteLeadRecord(id);
      if (!result.success && result.error) {
        setSyncError(`Failed to delete from cloud: ${result.error}`);
      }
    }
  };

  const startEditingNote = (id: string, currentNote: string) => {
    setEditingNoteId(id);
    setNoteText(currentNote || '');
  };

  const saveNote = async (id: string) => {
    const currentNoteText = noteText;
    
    // Optimistic UI update
    const updated = leads.map((l) => {
      if (l.id === id) {
        return { ...l, notes: currentNoteText };
      }
      return l;
    });
    setLeads(updated);
    setEditingNoteId(null);
    setNoteText('');

    // Sync to Firestore
    const result = await updateLead(id, { notes: currentNoteText });
    if (!result.success && result.error) {
      setSyncError(`Failed to save notes in cloud: ${result.error}`);
    }
  };

  const resetToSampleData = async () => {
    if (window.confirm('Would you like to reset the lead board to default sample queries for testing?')) {
      setIsLoading(true);
      setSyncError(null);
      await resetWithSampleData();
      await loadLeads();
    }
  };

  // Stats Calculations
  const totalLeadsCount = leads.length;
  const newLeadsCount = leads.filter((l) => l.status === 'new').length;
  const inProgressLeadsCount = leads.filter((l) => l.status === 'in_progress' || l.status === 'contacted').length;
  const closedLeadsCount = leads.filter((l) => l.status === 'closed').length;

  const filteredLeads = leads.filter((l) => {
    const matchesSearch =
      l.name.toLowerCase().includes(search.toLowerCase()) ||
      l.phone.includes(search) ||
      l.serviceType.toLowerCase().includes(search.toLowerCase()) ||
      (l.message && l.message.toLowerCase().includes(search.toLowerCase()));

    const matchesStatus = statusFilter === 'all' ? true : l.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: LeadInquiry['status']) => {
    switch (status) {
      case 'new':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-red-50 text-red-700 border border-red-100">
            <span className="w-1.5 h-1.5 rounded-full bg-red-600 mr-1.5 animate-pulse"></span>
            New Query
          </span>
        );
      case 'contacted':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-100">
            <PhoneCall className="w-3 h-3 mr-1 text-blue-500" />
            Contacted
          </span>
        );
      case 'in_progress':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-100">
            <Clock className="w-3 h-3 mr-1 text-amber-500" />
            Processing
          </span>
        );
      case 'closed':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-green-50 text-green-700 border border-green-100">
            <CheckCircle className="w-3 h-3 mr-1 text-green-500" />
            Completed
          </span>
        );
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-12 p-8 bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl text-white space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
        {/* Lock Screen UI Header */}
        <div className="flex flex-col items-center text-center space-y-3 pb-5 border-b border-slate-800/80">
          <div className="w-16 h-16 rounded-full bg-yellow-400/10 border border-yellow-400/30 flex items-center justify-center text-yellow-400 animate-pulse shadow-[0_0_20px_rgba(234,179,8,0.15)] mb-1">
            <Lock className="w-8 h-8" />
          </div>
          <h3 className="font-display font-bold text-2xl text-white">CRM Portal Locked</h3>
          <p className="text-slate-400 text-xs leading-relaxed max-w-xs">
            This panel displays private client lead submissions, contact info, and internal advisory logs. Please enter your consultant password.
          </p>
        </div>

        {/* Input Form */}
        <div className="space-y-4">
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                Consultant Password
              </label>
              <div className="relative rounded-xl shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <Key className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-10 py-3 bg-slate-950 border border-slate-800 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 transition-all placeholder:text-slate-700"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-white cursor-pointer transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {authError && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-300 rounded-lg text-xs leading-relaxed">
                ⚠️ {authError}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-yellow-400 hover:bg-yellow-350 active:scale-[0.98] text-blue-950 font-bold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <Unlock className="w-4 h-4" />
              Unlock Lead Board
            </button>
          </form>
        </div>

        {/* Demo Password Hint Box */}
        <div className="p-3 bg-slate-950 border border-slate-800/85 rounded-xl space-y-1">
          <span className="text-[10px] font-bold text-yellow-400/85 uppercase tracking-wider block">
            🔑 Consultant Credential Hint
          </span>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Your secure password is <code className="bg-slate-900 px-1.5 py-0.5 rounded text-yellow-400 font-mono font-bold">uttam@1214</code> (uttam + last 4 digits of contact number) or <code className="bg-slate-900 px-1.5 py-0.5 rounded text-slate-300 font-mono">admin123</code>.
          </p>
        </div>

        {/* Security Notice */}
        <div className="pt-3 border-t border-slate-800/60 flex items-center gap-2 text-[11px] text-slate-500">
          <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>Active session locks automatically when you close the browser.</span>
        </div>
      </div>
    );
  }

  return (
    <div id="admin-panel" className="space-y-6">
      {/* Banner Card */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-2xl p-6 sm:p-8 text-white shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border border-slate-700">
        <div>
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span className="inline-flex items-center px-3 py-1 bg-blue-500/10 text-blue-400 text-xs font-semibold rounded-full border border-blue-500/20">
              Uttam Mukherjee Advisory CRM
            </span>
            {syncSource === 'firestore' ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Cloud Synced (Firebase)
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20" title="Offline or restricted permission fallback">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                Offline/Local Cache
              </span>
            )}
          </div>
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-white">Lead Inquiries Board</h2>
          <p className="text-slate-400 text-sm mt-1">
            Track customer registrations, manage consultation schedules, and jot down follow-up notes.
          </p>
        </div>
        <div className="flex gap-2 shrink-0 flex-wrap">
          <button
            onClick={loadLeads}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 border border-slate-700 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-all cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-blue-400' : ''}`} />
            {isLoading ? 'Syncing...' : 'Refresh'}
          </button>
          <button
            onClick={resetToSampleData}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 border border-slate-700 hover:bg-slate-700 text-yellow-400 text-xs font-semibold rounded-xl transition-all cursor-pointer disabled:opacity-50"
          >
            <UserPlus className="w-3.5 h-3.5" />
            Load Test Leads
          </button>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 text-xs font-semibold rounded-xl transition-all cursor-pointer"
            title="Lock lead inquiries board and secure session"
          >
            <Lock className="w-3.5 h-3.5" />
            Lock Board
          </button>
        </div>
      </div>

      {/* Sync Error Banner */}
      {syncError && (
        <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-200 rounded-xl text-xs sm:text-sm flex justify-between items-center gap-2 shadow-sm animate-in fade-in duration-200">
          <div className="flex items-start gap-2">
            <span className="shrink-0 text-red-400 mt-0.5">⚠️</span>
            <div>
              <strong className="text-red-300 block mb-0.5">Firebase Project Offline Notice:</strong>
              <p className="text-red-200/85 text-xs leading-relaxed">
                {syncError}. All lead operations will use the secure LocalStorage cache. Leads will reside safely in your browser and automatically upload once a connection is re-established.
              </p>
            </div>
          </div>
          <button 
            onClick={() => setSyncError(null)} 
            className="text-red-400 hover:text-white font-bold cursor-pointer px-2 text-base self-start"
            title="Dismiss"
          >
            ✕
          </button>
        </div>
      )}

      {/* CRM Dashboard Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-slate-100 text-slate-700 rounded-lg shrink-0">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-gray-500 font-medium block">Total Inquiries</span>
            <span className="text-xl sm:text-2xl font-bold text-slate-900">{totalLeadsCount}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-red-50 text-red-600 rounded-lg shrink-0">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping absolute block"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 relative block"></span>
          </div>
          <div>
            <span className="text-xs text-gray-500 font-medium block">Action Needed</span>
            <span className="text-xl sm:text-2xl font-bold text-red-600">{newLeadsCount}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-lg shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-gray-500 font-medium block">Active Follow-up</span>
            <span className="text-xl sm:text-2xl font-bold text-blue-700">{inProgressLeadsCount}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-green-50 text-green-600 rounded-lg shrink-0">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-gray-500 font-medium block">Converted Client</span>
            <span className="text-xl sm:text-2xl font-bold text-green-700">{closedLeadsCount}</span>
          </div>
        </div>
      </div>

      {/* Control Panel: Filters & Search */}
      <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search leads by client name, mobile, query..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-800 focus:bg-white text-sm"
          />
        </div>

        <div className="flex gap-2 w-full md:w-auto overflow-x-auto shrink-0 py-1">
          <span className="inline-flex items-center text-xs text-gray-500 font-medium mr-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 mr-1" /> Status:
          </span>
          {[
            { id: 'all', label: 'All Leads' },
            { id: 'new', label: 'New' },
            { id: 'contacted', label: 'Contacted' },
            { id: 'in_progress', label: 'Processing' },
            { id: 'closed', label: 'Completed' },
          ].map((status) => (
            <button
              key={status.id}
              onClick={() => setStatusFilter(status.id)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                statusFilter === status.id
                  ? 'bg-blue-900 text-white shadow-sm'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {status.label}
            </button>
          ))}
        </div>
      </div>

      {/* Leads List */}
      <div id="leads-list-container" className="space-y-4">
        {filteredLeads.length > 0 ? (
          filteredLeads.map((lead) => (
            <div
              key={lead.id}
              id={`lead-card-${lead.id}`}
              className={`bg-white rounded-xl border shadow-sm overflow-hidden transition-all duration-200 ${
                lead.status === 'new'
                  ? 'border-l-4 border-l-red-500 border-gray-200'
                  : lead.status === 'closed'
                  ? 'border-l-4 border-l-green-500 border-gray-100 bg-gray-50/30'
                  : 'border-l-4 border-l-blue-500 border-gray-200'
              }`}
            >
              <div className="p-5 sm:p-6 space-y-4">
                {/* Header: Name, Date, Badges */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                  <div>
                    <h3 className="font-display font-bold text-lg text-slate-900">{lead.name}</h3>
                    <p className="text-xs text-slate-500">
                      Inquired on: {new Date(lead.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusBadge(lead.status)}
                    <span className="text-xs font-bold px-2.5 py-1 bg-slate-100 text-slate-800 rounded-lg border border-slate-200/50">
                      {lead.serviceType}
                    </span>
                  </div>
                </div>

                {/* Body: Contact, Message */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-1.5 text-sm">
                  <div className="space-y-1">
                    <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider">Contact Details</span>
                    <p className="font-semibold text-slate-800">📞 {lead.phone}</p>
                    <p className="text-slate-600 break-all">✉️ {lead.email || 'No email provided'}</p>
                  </div>

                  <div className="md:col-span-2 space-y-1 bg-gray-50 p-3 rounded-lg border border-gray-100">
                    <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">Message / Request Detail</span>
                    <p className="text-slate-700 italic leading-relaxed text-xs sm:text-sm">
                      "{lead.message || 'I am interested in a general insurance consultation.'}"
                    </p>
                  </div>
                </div>

                {/* Notes and Action controls */}
                <div className="pt-4 border-t border-gray-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  {/* Admin notes scratchpad */}
                  <div className="w-full md:max-w-xl">
                    {editingNoteId === lead.id ? (
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={noteText}
                          onChange={(e) => setNoteText(e.target.value)}
                          placeholder="Type personal follow-up notes..."
                          className="flex-grow px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-800 focus:bg-white"
                          autoFocus
                        />
                        <button
                          onClick={() => saveNote(lead.id)}
                          className="px-3 py-1.5 bg-blue-900 text-white rounded-lg text-xs font-bold hover:bg-blue-950 transition-colors cursor-pointer shrink-0"
                        >
                          Save
                        </button>
                        <button
                          onClick={() => setEditingNoteId(null)}
                          className="px-3 py-1.5 bg-gray-200 text-gray-700 rounded-lg text-xs font-bold hover:bg-gray-300 transition-colors cursor-pointer shrink-0"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <div className="text-xs text-slate-600">
                        <span className="font-semibold text-slate-800 block md:inline md:mr-1.5">Advisor Notes:</span>
                        {lead.notes ? (
                          <span className="italic text-slate-700">"{lead.notes}"</span>
                        ) : (
                          <span className="text-gray-400">No notes written yet. Click edit to write...</span>
                        )}
                        <button
                          onClick={() => startEditingNote(lead.id, lead.notes || '')}
                          className="ml-2 text-blue-800 hover:underline font-semibold cursor-pointer text-[11px]"
                        >
                          [Edit Notes]
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Status Updating & Deletion */}
                  <div className="flex items-center gap-3 w-full md:w-auto justify-end">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-medium text-gray-500">Update Status:</span>
                      <select
                        value={lead.status}
                        onChange={(e) => updateLeadStatus(lead.id, e.target.value as LeadInquiry['status'])}
                        className="px-2.5 py-1 bg-white border border-gray-200 rounded-lg text-xs font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-800 cursor-pointer"
                      >
                        <option value="new">New</option>
                        <option value="contacted">Contacted</option>
                        <option value="in_progress">Processing</option>
                        <option value="closed">Completed</option>
                      </select>
                    </div>

                    {/* Quick WhatsApp Link for Admin */}
                    <a
                      href={`https://wa.me/${lead.phone.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg border border-emerald-100 transition-colors"
                      title="Follow up on WhatsApp"
                    >
                      💬
                    </a>

                    <button
                      onClick={() => deleteLead(lead.id)}
                      className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg border border-gray-100 hover:border-red-100 transition-colors cursor-pointer"
                      title="Delete Record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-12 text-center">
            <ShieldAlert className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <h4 className="font-display font-semibold text-lg text-slate-800">No Lead Inquiries Found</h4>
            <p className="text-gray-500 text-sm max-w-sm mx-auto mt-1">
              There are no leads matching your search parameters or currently saved in the database.
            </p>
            <button
              onClick={resetToSampleData}
              className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-blue-900 text-white hover:bg-blue-950 text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5" />
              Populate Default Sample Leads
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
