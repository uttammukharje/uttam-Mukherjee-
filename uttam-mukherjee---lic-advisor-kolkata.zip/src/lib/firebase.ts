import { initializeApp } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy, 
  getDocFromServer
} from "firebase/firestore";
import { LeadInquiry } from "../types";

// User's Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyCz9qyKEcjEx1FOg_pSuReVCGUGiVn8KoE",
  authDomain: "uttam-mukherjee.firebaseapp.com",
  projectId: "uttam-mukherjee",
  storageBucket: "uttam-mukherjee.firebasestorage.app",
  messagingSenderId: "332766237687",
  appId: "1:332766237687:web:c447c6a0c917ce3ed6d4f2",
  measurementId: "G-SNBBG8C98W"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  };
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {},
    operationType,
    path
  };
  console.error('Firestore Error details: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const LEADS_COLLECTION = 'leads';

// Create a new lead in Firestore
export async function createFirestoreLead(lead: LeadInquiry): Promise<void> {
  try {
    const docRef = doc(db, LEADS_COLLECTION, lead.id);
    await setDoc(docRef, lead);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${LEADS_COLLECTION}/${lead.id}`);
  }
}

// Get all leads from Firestore sorted by creation date descending
export async function getFirestoreLeads(): Promise<LeadInquiry[]> {
  try {
    const leadsRef = collection(db, LEADS_COLLECTION);
    const q = query(leadsRef, orderBy('createdAt', 'desc'));
    const querySnapshot = await getDocs(q);
    const leads: LeadInquiry[] = [];
    querySnapshot.forEach((docSnap) => {
      leads.push(docSnap.data() as LeadInquiry);
    });
    return leads;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, LEADS_COLLECTION);
    return [];
  }
}

// Update a lead's status or notes in Firestore
export async function updateFirestoreLead(id: string, updates: Partial<LeadInquiry>): Promise<void> {
  try {
    const docRef = doc(db, LEADS_COLLECTION, id);
    await updateDoc(docRef, updates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${LEADS_COLLECTION}/${id}`);
  }
}

// Delete a lead from Firestore
export async function deleteFirestoreLead(id: string): Promise<void> {
  try {
    const docRef = doc(db, LEADS_COLLECTION, id);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${LEADS_COLLECTION}/${id}`);
  }
}

// Validate Connection to Firestore on application boot
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    console.warn("Firestore connectivity warning:", error);
    return false;
  }
}
