import { LeadInquiry } from '../types';
import { 
  createFirestoreLead, 
  getFirestoreLeads, 
  updateFirestoreLead, 
  deleteFirestoreLead 
} from './firebase';

const LOCAL_STORAGE_KEY = 'uttam_lic_leads';

const SAMPLE_LEADS: LeadInquiry[] = [
  {
    id: 'lead_sample1',
    name: 'Aravind Swamy',
    phone: '9830012345',
    email: 'aravind.swamy@gmail.com',
    serviceType: 'Child Future Plan',
    message: 'Need a proposal for Jeevan Lakshya (Table 733). Daughter is 3 years old. Budget ₹5000/month.',
    status: 'new',
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 mins ago
    notes: ''
  },
  {
    id: 'lead_sample2',
    name: 'Riya Sen',
    phone: '8910054321',
    email: 'riya.sen@yahoo.co.in',
    serviceType: 'Policy Loan Assistance',
    message: 'I have a Jeevan Labh (Table 736) policy of ₹10 Lakh sum assured. I need ₹2 Lakh loan urgently. Please tell process.',
    status: 'in_progress',
    createdAt: new Date(Date.now() - 1000 * 60 * 240).toISOString(), // 4 hours ago
    notes: 'Spoke with Riya. Checked her policy surrender value. Eligible for ₹2.4L loan. Scheduled branch visit at Maula Ali.'
  },
  {
    id: 'lead_sample3',
    name: 'Debashis Chatterjee',
    phone: '7003056789',
    email: 'debashis.c@outlook.com',
    serviceType: 'Retirement Planning',
    message: 'Looking for single premium immediate annuity or lifetime pension plan with guaranteed 8% return.',
    status: 'contacted',
    createdAt: new Date(Date.now() - 1000 * 60 * 1440).toISOString(), // 1 day ago
    notes: 'Emailed New Jeevan Shanti (Table 868) quote. Waiting for response.'
  },
  {
    id: 'lead_sample4',
    name: 'Dr. Soumitra Das',
    phone: '9433011223',
    email: 'soumitra.das@pgimer.edu',
    serviceType: 'Maturity Claim Assistance',
    message: 'My New Jeevan Anand policy (Table 875) is maturing next week. Need help with claim forms & door submission.',
    status: 'closed',
    createdAt: new Date(Date.now() - 1000 * 60 * 4320).toISOString(), // 3 days ago
    notes: 'Maturity form 3825 and NEFT submitted to City BR 11. Funds credited directly to bank account on Friday.'
  }
];

// Helper to load localStorage leads
export function getLocalStorageLeads(): LeadInquiry[] {
  const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }
  return [];
}

// Helper to save leads to localStorage
export function setLocalStorageLeads(leads: LeadInquiry[]): void {
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(leads));
}

// Initialize localStorage with samples if empty
export function initializeLocalStorageIfEmpty(): LeadInquiry[] {
  const leads = getLocalStorageLeads();
  if (leads.length === 0) {
    setLocalStorageLeads(SAMPLE_LEADS);
    return SAMPLE_LEADS;
  }
  return leads;
}

/**
 * Service to sync a newly created lead
 */
export async function saveLead(lead: LeadInquiry): Promise<{ success: boolean; error?: string }> {
  // 1. Immediately save to localStorage
  const currentLeads = getLocalStorageLeads();
  currentLeads.unshift(lead);
  setLocalStorageLeads(currentLeads);

  // 2. Attempt to save to Firestore
  try {
    await createFirestoreLead(lead);
    return { success: true };
  } catch (error: any) {
    console.error("Failed to sync new lead to Firestore:", error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : "Database write failed" 
    };
  }
}

/**
 * Service to fetch leads
 */
export async function fetchLeads(): Promise<{ 
  leads: LeadInquiry[]; 
  source: 'firestore' | 'localStorage'; 
  error?: string; 
}> {
  try {
    const firestoreLeads = await getFirestoreLeads();
    
    if (firestoreLeads && firestoreLeads.length > 0) {
      // Synchronize back to localStorage
      setLocalStorageLeads(firestoreLeads);
      return { leads: firestoreLeads, source: 'firestore' };
    } else {
      // If Firestore returned nothing or empty, check local
      const localLeads = initializeLocalStorageIfEmpty();
      return { leads: localLeads, source: 'localStorage' };
    }
  } catch (error: any) {
    console.error("Failed to fetch leads from Firestore, falling back to local storage:", error);
    const localLeads = initializeLocalStorageIfEmpty();
    return { 
      leads: localLeads, 
      source: 'localStorage', 
      error: error instanceof Error ? error.message : "Database connection failed" 
    };
  }
}

/**
 * Service to update a lead
 */
export async function updateLead(id: string, updates: Partial<LeadInquiry>): Promise<{ success: boolean; error?: string }> {
  // 1. Update localStorage immediately
  const localLeads = getLocalStorageLeads();
  const updatedLocal = localLeads.map(l => l.id === id ? { ...l, ...updates } : l);
  setLocalStorageLeads(updatedLocal);

  // 2. Update Firestore
  try {
    await updateFirestoreLead(id, updates);
    return { success: true };
  } catch (error: any) {
    console.error(`Failed to update lead ${id} in Firestore:`, error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : "Database update failed" 
    };
  }
}

/**
 * Service to delete a lead
 */
export async function deleteLeadRecord(id: string): Promise<{ success: boolean; error?: string }> {
  // 1. Delete from localStorage immediately
  const localLeads = getLocalStorageLeads();
  const filteredLocal = localLeads.filter(l => l.id !== id);
  setLocalStorageLeads(filteredLocal);

  // 2. Delete from Firestore
  try {
    await deleteFirestoreLead(id);
    return { success: true };
  } catch (error: any) {
    console.error(`Failed to delete lead ${id} from Firestore:`, error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : "Database deletion failed" 
    };
  }
}

/**
 * Reset local storage with sample data and try to push them to Firestore
 */
export async function resetWithSampleData(): Promise<LeadInquiry[]> {
  setLocalStorageLeads(SAMPLE_LEADS);
  
  // Try to bulk sync them to Firestore
  for (const lead of SAMPLE_LEADS) {
    try {
      await createFirestoreLead(lead);
    } catch (e) {
      console.warn("Could not sync sample lead to Firestore:", lead.id, e);
    }
  }
  return SAMPLE_LEADS;
}
