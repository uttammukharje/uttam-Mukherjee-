import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, ShieldCheck, Phone, Mail, Award, CheckCircle2, Star, 
  ChevronDown, Clock, MapPin, ExternalLink, Calendar, MessageSquare, 
  ArrowRight, UserCheck, HelpCircle, AlertCircle, TrendingUp, Users, X
} from 'lucide-react';

import Header from './components/Header';
import Footer from './components/Footer';
import ContactForm from './components/ContactForm';
import AdminDashboard from './components/AdminDashboard';
import PlanAssistant from './components/PlanAssistant';
import { SERVICES, LIC_PLANS, TESTIMONIALS, FAQS } from './data';
import { LeadInquiry } from './types';
import profilePhoto from './assets/profile_photo.jpeg';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [prefilledService, setPrefilledService] = useState('New Policy Consultation');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [newLeadCount, setNewLeadCount] = useState(0);
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);

  // Load new lead count to show badge
  useEffect(() => {
    const raw = localStorage.getItem('uttam_lic_leads');
    if (raw) {
      const leads: LeadInquiry[] = JSON.parse(raw);
      setNewLeadCount(leads.filter(l => l.status === 'new').length);
    }
  }, [activeTab]);

  const handleLeadSuccess = () => {
    // Refresh new lead count
    const raw = localStorage.getItem('uttam_lic_leads');
    if (raw) {
      const leads: LeadInquiry[] = JSON.parse(raw);
      setNewLeadCount(leads.filter(l => l.status === 'new').length);
    }
  };

  const handleServiceClick = (serviceTitle: string) => {
    setPrefilledService(serviceTitle);
    setActiveTab('contact');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePlanConsult = (planName: string, prefillNotes: string) => {
    setPrefilledService(planName + " Consultation");
    setActiveTab('contact');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getLucideIcon = (name: string) => {
    switch (name) {
      case 'ShieldCheck': return <ShieldCheck className="w-6 h-6" />;
      case 'GraduationCap': return <Award className="w-6 h-6" />; // Fallback suitable icon
      case 'Sparkles': return <TrendingUp className="w-6 h-6" />;
      case 'PiggyBank': return <TrendingUp className="w-6 h-6" />;
      case 'Coins': return <TrendingUp className="w-6 h-6" />;
      case 'FileText': return <CheckCircle2 className="w-6 h-6" />;
      case 'Gift': return <Award className="w-6 h-6" />;
      case 'UserCheck': return <UserCheck className="w-6 h-6" />;
      case 'RefreshCw': return <AlertCircle className="w-6 h-6" />;
      case 'CreditCard': return <CheckCircle2 className="w-6 h-6" />;
      case 'MapPin': return <MapPin className="w-6 h-6" />;
      case 'PhoneCall': return <Phone className="w-6 h-6" />;
      default: return <Shield className="w-6 h-6" />;
    }
  };

  return (
    <div id="advisor-portal" className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-blue-900 selection:text-white">
      {/* Sticky Header */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="w-full"
          >
            {/* HOME VIEW */}
            {activeTab === 'home' && (
              <div id="view-home" className="space-y-16 pb-20">
                {/* Hero Section */}
                <section className="relative bg-gradient-to-r from-blue-900 via-indigo-950 to-blue-950 text-white pt-20 pb-28 px-4 overflow-hidden border-b border-blue-950">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(59,130,246,0.15),transparent_60%)]"></div>
                  <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
                    
                    {/* Left Hero: Brand Content */}
                    <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
                      <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-yellow-400/10 border border-yellow-400/20 rounded-full text-yellow-400 text-xs font-semibold uppercase tracking-wider">
                        <Award className="w-3.5 h-3.5" /> Licensed LIC Consultant (3+ Years Experience)
                      </div>
                      
                      <h2 className="font-display font-extrabold text-3xl sm:text-4xl md:text-5xl leading-tight text-white">
                        Secure Your Family's Future with <span className="text-yellow-400">Sovereign Trust</span>
                      </h2>
                      
                      <p className="text-blue-100 text-sm sm:text-base md:text-lg max-w-2xl leading-relaxed mx-auto lg:mx-0">
                        Maximize your savings, secure tax-free pensions, and plan higher education milestones with specialized LIC policies. Trusted advisor to over 2,400+ happy clients in Kolkata.
                      </p>

                      <div className="pt-4 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                        <button
                          onClick={() => {
                            setPrefilledService('New Policy Consultation');
                            setActiveTab('contact');
                          }}
                          className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-yellow-400 to-amber-500 hover:from-yellow-500 hover:to-amber-600 text-blue-950 font-sans font-bold rounded-xl shadow-lg transition-transform hover:-translate-y-0.5 cursor-pointer text-sm"
                        >
                          Book Free Consultation
                        </button>
                        <button
                          onClick={() => setActiveTab('plans')}
                          className="w-full sm:w-auto px-8 py-3.5 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-sans font-semibold rounded-xl transition-all cursor-pointer text-sm"
                        >
                          Explore LIC Plans
                        </button>
                      </div>

                      {/* Micro Credential Lines */}
                      <div className="pt-6 grid grid-cols-3 gap-4 border-t border-white/10 max-w-lg mx-auto lg:mx-0">
                        <div>
                          <p className="text-xl sm:text-2xl font-bold text-yellow-400">3+ Yrs</p>
                          <p className="text-[10px] text-blue-200 uppercase tracking-wider font-medium">Of Trusted Advisory</p>
                        </div>
                        <div>
                          <p className="text-xl sm:text-2xl font-bold text-yellow-400">2,400+</p>
                          <p className="text-[10px] text-blue-200 uppercase tracking-wider font-medium">Families Protected</p>
                        </div>
                        <div>
                          <p className="text-xl sm:text-2xl font-bold text-yellow-400">100%</p>
                          <p className="text-[10px] text-blue-200 uppercase tracking-wider font-medium">Claim Settlement Help</p>
                        </div>
                      </div>
                    </div>

                    {/* Right Hero: Visual Portrait or Form Card */}
                    <div className="lg:col-span-5 w-full">
                      <div className="bg-white/5 backdrop-blur-sm p-6 rounded-2xl border border-white/10 space-y-4">
                        <div className="flex items-center space-x-3 pb-3 border-b border-white/10">
                          <div 
                            onClick={() => setIsPhotoModalOpen(true)}
                            className="w-16 h-16 rounded-full overflow-hidden shrink-0 border-2 border-yellow-400 bg-slate-850 cursor-pointer hover:scale-105 active:scale-95 transition-all duration-200 relative group"
                            title="Click to view full photo"
                          >
                            <img 
                              src={profilePhoto} 
                              alt="Uttam Mukherjee" 
                              className="w-full h-full object-cover group-hover:brightness-90 transition-all duration-200"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all duration-200">
                              <span className="text-[9px] text-white font-bold tracking-wider uppercase">ZOOM</span>
                            </div>
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold text-white">Uttam Mukherjee</h3>
                              <span className="text-[9px] bg-yellow-400/20 text-yellow-400 px-1.5 py-0.5 rounded font-mono uppercase tracking-wider font-bold">LIC Advisor</span>
                            </div>
                            <p className="text-xs text-blue-200">Kolkata City Branch 11 Specialist</p>
                            <button 
                              onClick={() => setIsPhotoModalOpen(true)}
                              className="text-[10px] text-yellow-400/85 hover:text-yellow-400 underline transition-colors cursor-pointer text-left mt-0.5 block"
                            >
                              🔍 Click to enlarge photo
                            </button>
                          </div>
                        </div>
                        <ul className="space-y-2 text-xs sm:text-sm text-blue-100">
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                            <span>Custom HLV (Human Life Value) Analysis</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                            <span>Online NACH & Premium Setup Support</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                            <span>Doorstep Claim File collections (Kolkata region)</span>
                          </li>
                        </ul>
                        <div className="pt-2">
                          <button
                            onClick={() => {
                              setActiveTab('plans');
                            }}
                            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-sans font-semibold rounded-xl transition-colors text-xs uppercase tracking-wider shadow-inner"
                          >
                            🚀 Calculate Your Plan Match
                          </button>
                        </div>
                      </div>
                    </div>

                  </div>
                </section>

                {/* Trust Statistics / Badges in light bg */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-20">
                  <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6 sm:p-8 grid grid-cols-1 md:grid-cols-3 gap-6 text-center divide-y md:divide-y-0 md:divide-x divide-gray-100">
                    <div className="p-4 space-y-1">
                      <div className="w-10 h-10 bg-blue-50 text-blue-800 rounded-full flex items-center justify-center mx-auto mb-2">
                        <Shield className="w-5 h-5" />
                      </div>
                      <h4 className="font-display font-bold text-lg text-slate-900">Sovereign Guarantee</h4>
                      <p className="text-xs text-slate-500 max-w-xs mx-auto">
                        All LIC policy returns and values are 100% guaranteed by the Government of India under Section 37 of LIC Act.
                      </p>
                    </div>

                    <div className="p-4 space-y-1">
                      <div className="w-10 h-10 bg-yellow-50 text-yellow-600 rounded-full flex items-center justify-center mx-auto mb-2">
                        <Users className="w-5 h-5" />
                      </div>
                      <h4 className="font-display font-bold text-lg text-slate-900">2,400+ Protected Clients</h4>
                      <p className="text-xs text-slate-500 max-w-xs mx-auto">
                        Helping retail workers, medical professionals, and local corporate executives build bulletproof financial covers.
                      </p>
                    </div>

                    <div className="p-4 space-y-1">
                      <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
                        <Award className="w-5 h-5" />
                      </div>
                      <h4 className="font-display font-bold text-lg text-slate-900">Expert Claim Settlement</h4>
                      <p className="text-xs text-slate-500 max-w-xs mx-auto">
                        Complete support in processing maturity forms, loan approvals, nomination endorsements, and death settlements.
                      </p>
                    </div>
                  </div>
                </section>

                {/* Services Section Preview */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
                  <div className="text-center space-y-2">
                    <span className="text-xs font-bold uppercase tracking-widest text-blue-800">What I Do</span>
                    <h3 className="font-display font-bold text-2xl sm:text-3xl text-slate-950">Professional Advisory Services</h3>
                    <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto">
                      Explore detailed services categorised for financial safety and operational LIC policy assistance.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {SERVICES.slice(0, 4).map((service) => (
                      <div
                        key={service.id}
                        id={`service-card-${service.id}`}
                        className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-all group flex flex-col justify-between"
                      >
                        <div className="space-y-4">
                          <div className="w-12 h-12 bg-blue-50 text-blue-800 rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
                            {getLucideIcon(service.iconName)}
                          </div>
                          <div>
                            <h4 className="font-display font-bold text-slate-900 text-base">{service.title}</h4>
                            <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">{service.description}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => handleServiceClick(service.title)}
                          className="mt-6 flex items-center text-xs font-bold text-blue-900 group-hover:text-blue-700 cursor-pointer"
                        >
                          Get Started <ArrowRight className="w-3 h-3 ml-1 group-hover:translate-x-1 transition-transform" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="text-center">
                    <button
                      onClick={() => setActiveTab('services')}
                      className="inline-flex items-center gap-1.5 text-sm font-bold text-blue-800 hover:text-blue-950 hover:underline cursor-pointer"
                    >
                      View All 12 Advisory & Policy Services
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </section>

                {/* Why Choose Me Section */}
                <section className="bg-slate-900 text-white py-16 px-4">
                  <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <div className="space-y-6">
                      <span className="text-xs font-bold text-blue-400 uppercase tracking-widest">Why Choose Me</span>
                      <h3 className="font-display font-bold text-3xl text-white">Certified Sincerity & 24/7 Availability</h3>
                      <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                        Financial planning isn't about selling a policy; it's about evaluating human life values, analyzing long-term liabilities, and matching them with plans that never disappoint.
                      </p>
                      
                      <ul className="space-y-4 text-sm">
                        {[
                          { title: 'LIC Certified Advisor', desc: 'Officially registered consultant backed by West Bengal IRDAI' },
                          { title: 'Personalized Financial Sitting', desc: 'No cookie-cutter plans. Custom proposals based on exact age and cashflow.' },
                          { title: 'Fast & Doorstep Claim Support', desc: 'We collect your maturity forms and visit Maula Ali branch to clear delays.' },
                        ].map((point, index) => (
                          <li key={index} className="flex items-start gap-3">
                            <div className="w-5 h-5 bg-blue-500/15 text-blue-400 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                              ✓
                            </div>
                            <div>
                              <span className="font-bold text-slate-100 block">{point.title}</span>
                              <span className="text-xs text-slate-400">{point.desc}</span>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-slate-850 p-6 sm:p-8 rounded-2xl border border-slate-800 space-y-6">
                      <h4 className="font-display font-bold text-lg text-white">Client Milestone Calculator</h4>
                      <p className="text-xs text-slate-400">
                        Answer our quick diagnostic questions to see which plans suit you before you schedule a phone sitting.
                      </p>
                      <button
                        onClick={() => setActiveTab('plans')}
                        className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-sans font-semibold rounded-xl text-xs uppercase tracking-wider"
                      >
                        🎯 Start AI Matcher Wizard
                      </button>
                    </div>
                  </div>
                </section>

                {/* Testimonial Section */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
                  <div className="text-center space-y-2">
                    <span className="text-xs font-bold uppercase tracking-widest text-blue-800">Reviews</span>
                    <h3 className="font-display font-bold text-2xl sm:text-3xl text-slate-950">What Clients Say About Uttam Da</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {TESTIMONIALS.map((t, idx) => (
                      <div key={idx} className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-col justify-between">
                        <div className="space-y-4">
                          <div className="flex gap-0.5">
                            {[...Array(t.rating)].map((_, i) => (
                              <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            ))}
                          </div>
                          <p className="text-xs sm:text-sm text-slate-600 italic">"{t.content}"</p>
                        </div>
                        <div className="pt-6 border-t border-gray-50 mt-6">
                          <p className="font-bold text-slate-900 text-sm">{t.name}</p>
                          <p className="text-[10px] text-gray-500 font-medium">{t.role}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                {/* FAQs Section */}
                <section className="max-w-5xl mx-auto px-4 sm:px-6 space-y-6">
                  <h3 className="font-display font-bold text-2xl text-slate-950 text-center mb-8">Frequently Asked Questions</h3>
                  <div className="space-y-3">
                    {FAQS.map((faq, idx) => (
                      <div key={idx} className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                        <button
                          onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                          className="w-full text-left px-5 py-4 flex justify-between items-center hover:bg-gray-50/50 cursor-pointer"
                        >
                          <span className="font-sans font-semibold text-sm sm:text-base text-slate-900">{faq.question}</span>
                          <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${expandedFaq === idx ? 'rotate-180' : ''}`} />
                        </button>
                        {expandedFaq === idx && (
                          <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 border-t border-gray-50 leading-relaxed animate-in fade-in duration-200">
                            {faq.answer}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </section>

                {/* Final Home CTA banner */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="bg-gradient-to-r from-blue-800 to-indigo-900 rounded-3xl p-8 sm:p-12 text-white text-center space-y-6 shadow-xl border border-indigo-950 relative overflow-hidden">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_80%,rgba(234,179,8,0.08),transparent_50%)]"></div>
                    <div className="max-w-2xl mx-auto space-y-4 relative z-10">
                      <h4 className="font-display font-bold text-2xl sm:text-4xl text-white">Ready to Secure Your Family's Dreams?</h4>
                      <p className="text-blue-100 text-sm sm:text-base">
                        Get zero-cost customized financial proposals. Request your sitting today and get absolute clarity.
                      </p>
                      <div className="pt-4 flex flex-col sm:flex-row justify-center gap-3">
                        <a
                          href="tel:+917439001214"
                          className="px-6 py-3 bg-white text-blue-950 font-bold rounded-xl text-sm hover:bg-blue-50 transition-colors flex items-center justify-center gap-1.5"
                        >
                          <Phone className="w-4 h-4" /> Call Now: 7439001214
                        </a>
                        <a
                          href="https://wa.me/917439001214?text=Hi%20Uttam%20Ji%2C%20I%20am%20interested%20in%20arranging%20a%20free%20sitting%20for%20LIC%20insurance."
                          target="_blank"
                          rel="noreferrer"
                          className="px-6 py-3 bg-emerald-600 text-white font-bold rounded-xl text-sm hover:bg-emerald-700 transition-colors flex items-center justify-center gap-1.5"
                        >
                          <MessageSquare className="w-4 h-4" /> Chat on WhatsApp
                        </a>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            )}

            {/* ABOUT ME VIEW */}
            {activeTab === 'about' && (
              <div id="view-about" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  {/* Left Column: Portrait and Info badge */}
                  <div className="lg:col-span-5 space-y-6">
                    <div className="bg-gradient-to-br from-blue-900 to-indigo-950 p-8 rounded-2xl border border-blue-950 text-white shadow-xl space-y-6 text-center">
                      <div 
                        onClick={() => setIsPhotoModalOpen(true)}
                        className="w-48 h-48 sm:w-60 sm:h-60 rounded-2xl overflow-hidden mx-auto shadow-2xl border-4 border-indigo-900 bg-slate-800 cursor-pointer hover:scale-105 active:scale-95 transition-all duration-300 relative group ring-2 ring-yellow-400/50"
                        title="Click to view full screen"
                      >
                        <img 
                          src={profilePhoto} 
                          alt="Uttam Mukherjee Profile Photo" 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center transition-all duration-300">
                          <span className="text-xs text-white font-bold tracking-widest uppercase mb-1">🔍 CLICK TO ZOOM</span>
                          <span className="text-[10px] text-yellow-400 font-medium">View Full Resolution</span>
                        </div>
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-2xl">Uttam Mukherjee</h3>
                        <p className="text-yellow-400 text-xs uppercase tracking-wider font-semibold mt-1">LIC Certified Advisor & Financial planner</p>
                        <p className="text-slate-400 text-[11px] mt-1">ID: City BR 11 / 03177724</p>
                      </div>
                      <div className="pt-4 border-t border-white/10 grid grid-cols-2 gap-4 text-xs">
                        <div className="p-3 bg-white/5 rounded-xl">
                          <p className="text-slate-400">Headquarters</p>
                          <p className="font-bold text-white mt-0.5">Maula Ali, Kolkata</p>
                        </div>
                        <div className="p-3 bg-white/5 rounded-xl">
                          <p className="text-slate-400">Total Cover</p>
                          <p className="font-bold text-white mt-0.5">₹18+ Crore Sum</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Bio */}
                  <div className="lg:col-span-7 space-y-6">
                    <span className="text-xs font-bold uppercase tracking-widest text-blue-800">Who I Am</span>
                    <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900">Dedicated Financial Consultant</h2>
                    <p className="text-slate-600 leading-relaxed text-sm sm:text-base">
                      I am Uttam Mukherjee, a certified LIC Consultant helping individuals and families across West Bengal choose the right insurance plans for financial security, child future milestones, lifetime retirement pensions, and Section 80C tax savings.
                    </p>
                    <p className="text-slate-600 leading-relaxed text-sm sm:text-base">
                      With over 3 years of industry experience and an active attachment to LIC’s premium Kolkata City Branch 11, my focus is not merely policy activation. My goal is to serve as a long-term partner—assisting you with policy premium payments, NACH auto-debit registrations, emergency loans against policies, and securing prompt maturity claims directly to your bank account.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 text-xs sm:text-sm">
                      {[
                        { title: 'Personal Guidance', desc: 'Detailed calculation of Human Life Value (HLV) limits.' },
                        { title: 'Sovereign Security Focus', desc: 'Promoting 100% safe instruments backed by Govt of India.' },
                        { title: 'Kolkata Region Door Support', desc: 'Doorstep document collections for elderly citizens & claims.' },
                        { title: 'Hassle-Free Settlement', desc: 'Direct coordination with Maula Ali branch officers for faster clearance.' },
                      ].map((card, i) => (
                        <div key={i} className="p-4 bg-white rounded-xl border border-gray-100 shadow-sm flex items-start gap-3">
                          <div className="w-5 h-5 bg-blue-50 text-blue-800 rounded-full flex items-center justify-center shrink-0 mt-0.5 font-bold">✓</div>
                          <div>
                            <span className="font-bold text-slate-950 block">{card.title}</span>
                            <span className="text-slate-500 text-xs block mt-0.5">{card.desc}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Interactive Branch Banner Map Card */}
                <div className="bg-white p-6 sm:p-8 rounded-2xl border border-gray-100 shadow-sm space-y-6">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-100 pb-5">
                    <div>
                      <h3 className="font-display font-bold text-xl text-slate-950">Maula Ali Branch Location</h3>
                      <p className="text-xs text-slate-500 mt-0.5">73, Lenin Sarani Rd, Maula Ali, Taltala, Kolkata, West Bengal 700013</p>
                    </div>
                    <a
                      href="https://maps.google.com/?q=73,+Lenin+Sarani+Rd,+Maula+Ali,+Taltala,+Kolkata,+West+Bengal+700013"
                      target="_blank"
                      rel="noreferrer"
                      className="px-4 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-100 text-xs font-bold flex items-center gap-1 shrink-0"
                    >
                      Open in Google Maps <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="p-4 bg-gray-50 rounded-xl border border-gray-100/80 space-y-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">Office Timing</span>
                      <p className="text-sm font-semibold text-slate-800">Monday - Friday: 10:00 AM - 05:30 PM</p>
                      <p className="text-sm font-semibold text-slate-800">Saturday: 10:00 AM - 01:30 PM</p>
                    </div>

                    <div className="p-4 bg-gray-50 rounded-xl border border-gray-100/80 space-y-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">Assistance Area</span>
                      <p className="text-sm font-semibold text-slate-800">Kolkata Central, Salt Lake, Tollygunge, Behala, Howrah, and suburbs.</p>
                    </div>

                    <div className="p-4 bg-gray-50 rounded-xl border border-gray-100/80 space-y-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">Contact Info</span>
                      <p className="text-sm font-semibold text-slate-800">Call: +91 7439001214</p>
                      <p className="text-sm font-semibold text-slate-800">Email: uttammukhopadhyay777@gmail.com</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SERVICES VIEW */}
            {activeTab === 'services' && (
              <div id="view-services" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-12">
                <div className="text-center space-y-2 max-w-xl mx-auto">
                  <span className="text-xs font-bold uppercase tracking-widest text-blue-800">Complete Catalog</span>
                  <h2 className="font-display font-extrabold text-3xl text-slate-900">LIC Policy & Financial Planning Support</h2>
                  <p className="text-slate-500 text-sm sm:text-base">
                    Click any service card to immediately schedule a custom consultation and get help with your specific policy issue.
                  </p>
                </div>

                {/* Tab 1: Financial planning */}
                <div className="space-y-6">
                  <h3 className="font-display font-bold text-xl text-slate-900 border-b border-gray-100 pb-2 flex items-center gap-2">
                    <span className="w-2 h-5 bg-blue-800 rounded"></span> Financial Planning Services
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {SERVICES.filter(s => s.category === 'financial').map((service) => (
                      <div
                        key={service.id}
                        className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                      >
                        <div className="space-y-4">
                          <div className="w-12 h-12 bg-blue-50 text-blue-800 rounded-xl flex items-center justify-center">
                            {getLucideIcon(service.iconName)}
                          </div>
                          <div>
                            <h4 className="font-display font-bold text-slate-900 text-base">{service.title}</h4>
                            <p className="text-xs text-slate-500 mt-2 leading-relaxed">{service.description}</p>
                            <p className="text-xs text-slate-600 mt-3 pt-3 border-t border-gray-50 italic">
                              {service.detailedInfo}
                            </p>
                          </div>
                        </div>
                        <button
                          onClick={() => handleServiceClick(service.title)}
                          className="w-full mt-6 py-2 bg-blue-50 text-blue-900 hover:bg-blue-900 hover:text-white rounded-lg text-xs font-bold transition-all cursor-pointer"
                        >
                          Request Free Sitting
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Tab 2: LIC Policy operations */}
                <div className="space-y-6 pt-6">
                  <h3 className="font-display font-bold text-xl text-slate-900 border-b border-gray-100 pb-2 flex items-center gap-2">
                    <span className="w-2 h-5 bg-blue-800 rounded"></span> LIC Policy Operations & Support
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {SERVICES.filter(s => s.category === 'policy').map((service) => (
                      <div
                        key={service.id}
                        className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                      >
                        <div className="space-y-4">
                          <div className="w-12 h-12 bg-yellow-50 text-yellow-600 rounded-xl flex items-center justify-center">
                            {getLucideIcon(service.iconName)}
                          </div>
                          <div>
                            <h4 className="font-display font-bold text-slate-900 text-base">{service.title}</h4>
                            <p className="text-xs text-slate-500 mt-2 leading-relaxed">{service.description}</p>
                            <p className="text-xs text-slate-600 mt-3 pt-3 border-t border-gray-50 italic">
                              {service.detailedInfo}
                            </p>
                          </div>
                        </div>
                        <button
                          onClick={() => handleServiceClick(service.title)}
                          className="w-full mt-6 py-2 bg-blue-50 text-blue-900 hover:bg-blue-900 hover:text-white rounded-lg text-xs font-bold transition-all cursor-pointer"
                        >
                          Solve This Issue
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* PLANS VIEW */}
            {activeTab === 'plans' && (
              <div id="view-plans" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
                
                {/* Embedded Plan Recommendation Wizard */}
                <section className="space-y-6">
                  <div className="text-center space-y-2 max-w-xl mx-auto">
                    <span className="text-xs font-bold uppercase tracking-widest text-blue-800">Plan Matcher</span>
                    <h2 className="font-display font-extrabold text-3xl text-slate-900">Interactive Plan Finder</h2>
                    <p className="text-slate-500 text-sm">
                      Complete our diagnostic simulator below to check eligibility, estimate maturity bonuses, and find your perfect policy match instantly.
                    </p>
                  </div>
                  <PlanAssistant onPlanSelected={handlePlanConsult} />
                </section>

                {/* Complete Plans Catalog Grid */}
                <section className="space-y-8">
                  <div className="border-b border-gray-100 pb-3">
                    <h3 className="font-display font-bold text-2xl text-slate-950">Primary LIC Plan Portfolios</h3>
                    <p className="text-xs text-slate-500 mt-0.5">Explore the highest-demand plans currently subscribed by corporate employees and doctors in Kolkata.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {LIC_PLANS.map((plan) => (
                      <div
                        key={plan.id}
                        id={`plan-card-${plan.id}`}
                        className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden flex flex-col justify-between"
                      >
                        {/* Upper content */}
                        <div className="p-6 space-y-4">
                          <div className="flex justify-between items-start gap-2">
                            <div>
                              <h4 className="font-display font-bold text-lg text-slate-900 leading-tight">{plan.name}</h4>
                              <span className="text-[10px] font-bold text-blue-800 tracking-wider bg-blue-50 px-2 py-0.5 rounded-md mt-1 inline-block border border-blue-100/40">
                                {plan.tableNo}
                              </span>
                            </div>
                            <span className="text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-1 rounded bg-slate-100 text-slate-800">
                              {plan.category === 'child' ? '🎓 Child Future' : plan.category === 'retirement' ? '👴 Pension' : plan.category === 'term' ? '🛡️ Term Cover' : '💰 Endowment'}
                            </span>
                          </div>

                          <p className="text-xs text-slate-500 leading-relaxed italic">"{plan.description}"</p>

                          {/* Benefits list */}
                          <div className="space-y-2 pt-3 border-t border-gray-50">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block">Core Advantages:</span>
                            <ul className="space-y-1.5">
                              {plan.keyBenefits.map((benefit, i) => (
                                <li key={i} className="text-xs text-slate-600 flex items-start">
                                  <span className="text-blue-800 font-bold mr-1.5 shrink-0">✓</span>
                                  <span>{benefit}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Age Limits criteria */}
                          <div className="pt-3 text-[11px] text-gray-400 space-y-1">
                            <p>🎯 <span className="font-semibold text-slate-600">Ideal For:</span> {plan.targetAudience}</p>
                            <p>⏳ <span className="font-semibold text-slate-600">Age Entry:</span> {plan.minAge} to {plan.maxAge} years</p>
                          </div>
                        </div>

                        {/* Button CTA */}
                        <div className="p-4 bg-gray-50 border-t border-gray-100">
                          <button
                            onClick={() => handlePlanConsult(plan.name, `Interested in general details for ${plan.name} (${plan.tableNo}).`)}
                            className="w-full py-2.5 bg-blue-900 hover:bg-blue-950 text-white font-sans font-bold rounded-lg text-xs uppercase tracking-wider shadow-sm transition-colors cursor-pointer"
                          >
                            Request Custom Quotation
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            )}

            {/* CONTACT VIEW */}
            {activeTab === 'contact' && (
              <div id="view-contact" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-12">
                <div className="text-center space-y-2 max-w-xl mx-auto">
                  <span className="text-xs font-bold uppercase tracking-widest text-blue-800">Get In Touch</span>
                  <h2 className="font-display font-extrabold text-3xl text-slate-900">Schedule Your Free Financial Sitting</h2>
                  <p className="text-slate-500 text-sm">
                    Connect online or arrange a doorstep visit in Central/South Kolkata. Speak directly with advisor Uttam Mukherjee.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
                  
                  {/* Left Column: Form component */}
                  <div className="lg:col-span-7">
                    <ContactForm prefilledService={prefilledService} onSuccess={handleLeadSuccess} />
                  </div>

                  {/* Right Column: Contact Details Cards & Google Map link */}
                  <div className="lg:col-span-5 flex flex-col justify-between gap-6">
                    <div className="bg-white rounded-2xl border border-gray-100 p-6 sm:p-8 shadow-xl space-y-6 flex-grow flex flex-col justify-between">
                      <div className="space-y-6">
                        <div className="border-b border-gray-100 pb-4">
                          <h3 className="font-display font-bold text-lg text-slate-950">Direct Contact Credentials</h3>
                          <p className="text-xs text-gray-400 mt-0.5">Official LIC Certified Advisor Kolkata</p>
                        </div>

                        <ul className="space-y-4.5 text-sm text-slate-700">
                          <li className="flex items-start">
                            <div className="w-10 h-10 bg-blue-50 text-blue-800 rounded-lg flex items-center justify-center shrink-0 mr-3.5 mt-0.5">
                              📞
                            </div>
                            <div>
                              <span className="text-xs text-slate-400 block font-semibold uppercase tracking-wider">Mobile Phone</span>
                              <a href="tel:+917439001214" className="font-bold text-slate-900 hover:underline text-lg">
                                +91 74390 01214
                              </a>
                            </div>
                          </li>

                          <li className="flex items-start">
                            <div className="w-10 h-10 bg-blue-50 text-blue-800 rounded-lg flex items-center justify-center shrink-0 mr-3.5 mt-0.5">
                              ✉️
                            </div>
                            <div>
                              <span className="text-xs text-slate-400 block font-semibold uppercase tracking-wider">Official Email</span>
                              <a href="mailto:uttammukhopadhyay777@gmail.com" className="font-bold text-slate-900 hover:underline break-all">
                                uttammukhopadhyay777@gmail.com
                              </a>
                            </div>
                          </li>

                          <li className="flex items-start">
                            <div className="w-10 h-10 bg-blue-50 text-blue-800 rounded-lg flex items-center justify-center shrink-0 mr-3.5 mt-0.5">
                              📍
                            </div>
                            <div>
                              <span className="text-xs text-slate-400 block font-semibold uppercase tracking-wider">LIC Branch Office</span>
                              <span className="font-semibold text-slate-800 leading-relaxed block">
                                LIC City Branch 11, 73, Lenin Sarani Rd, Maula Ali, Taltala, Kolkata, WB 700013
                              </span>
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="pt-6 border-t border-gray-50 flex gap-2">
                        <a
                          href="tel:+917439001214"
                          className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs uppercase tracking-wider shadow-sm transition-colors cursor-pointer"
                        >
                          <Phone className="w-3.5 h-3.5" /> Call Advisor
                        </a>
                        <a
                          href="https://wa.me/917439001214?text=Hi%20Uttam%20Ji%2C%20I%20am%20interested%20in%20arranging%20a%20free%20sitting%20for%20LIC%20insurance."
                          target="_blank"
                          rel="noreferrer"
                          className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider shadow-sm transition-colors cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5" /> WhatsApp
                        </a>
                      </div>
                    </div>

                    {/* Vector Mock Map Box */}
                    <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 shadow-md flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-500/10 text-blue-400 rounded-xl flex items-center justify-center shrink-0">
                        📍
                      </div>
                      <div className="flex-grow space-y-1">
                        <h4 className="font-display font-semibold text-sm">Need Help Navigating?</h4>
                        <p className="text-slate-400 text-xs">Our office is adjacent to Maula Ali Dargah bus stop on Lenin Sarani Road.</p>
                        <a
                          href="https://maps.google.com/?q=73,+Lenin+Sarani+Rd,+Maula+Ali,+Taltala,+Kolkata,+West+Bengal+700013"
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center text-[11px] text-yellow-400 font-bold hover:underline gap-0.5 pt-1"
                        >
                          Get Route Navigation <ArrowRight className="w-3 h-3" />
                        </a>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            )}

            {/* ADMIN LEAD MANAGER VIEW */}
            {activeTab === 'admin' && (
              <div id="view-admin" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
                <AdminDashboard />
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* FOOTER */}
      <Footer setActiveTab={setActiveTab} />

      {/* Floating Action WhatsApp Button */}
      <a
        href="https://wa.me/917439001214?text=Hi%20Uttam%20Ji%2C%20I%20visited%20your%20website%20and%20need%20LIC%20service%20consultation."
        target="_blank"
        rel="noreferrer"
        id="floating-whatsapp-btn"
        className="fixed bottom-6 right-6 z-40 bg-emerald-600 hover:bg-emerald-500 text-white p-4 rounded-full shadow-2xl flex items-center justify-center hover:scale-105 transition-all duration-300 ring-4 ring-emerald-600/20 group"
        title="Chat on WhatsApp"
      >
        <MessageSquare className="w-6 h-6 shrink-0" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs group-hover:ml-2 transition-all duration-300 font-sans font-bold text-xs uppercase tracking-wider whitespace-nowrap">
          WhatsApp Support
        </span>
      </a>

      {/* Admin CRM Notification Alert helper (Bottom Left) */}
      {newLeadCount > 0 && activeTab !== 'admin' && (
        <div
          id="crm-alert-box"
          onClick={() => {
            setActiveTab('admin');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="fixed bottom-6 left-6 z-40 bg-slate-900 border border-slate-850 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 cursor-pointer hover:bg-slate-850 transition-all duration-200 animate-bounce"
        >
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
          </span>
          <div className="text-xs">
            <p className="font-bold">{newLeadCount} New Leads Registered</p>
            <p className="text-slate-400 text-[10px] mt-0.5">Click to view in Advisor Panel</p>
          </div>
        </div>
      )}

      {/* Lightbox Modal for Profile Photo */}
      <AnimatePresence>
        {isPhotoModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsPhotoModalOpen(false)}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-zoom-out"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-sm w-full bg-slate-900 border border-slate-850 rounded-2xl overflow-hidden shadow-2xl cursor-default"
            >
              <div className="absolute top-4 right-4 z-10">
                <button
                  onClick={() => setIsPhotoModalOpen(false)}
                  className="bg-black/60 hover:bg-black/80 text-white hover:text-yellow-400 p-2 rounded-full transition-all cursor-pointer shadow-lg"
                  title="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* High-Resolution Photo */}
              <div className="aspect-[3/4] w-full overflow-hidden bg-slate-950">
                <img
                  src={profilePhoto}
                  alt="Uttam Mukherjee Portrait"
                  className="w-full h-full object-cover select-none"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Description Footer */}
              <div className="p-6 text-center space-y-2 bg-slate-900 border-t border-slate-800 text-white">
                <h4 className="font-display font-bold text-xl">Uttam Mukherjee</h4>
                <p className="text-xs text-yellow-400 font-semibold uppercase tracking-wider">LIC Certified Consultant & Wealth Partner</p>
                <p className="text-slate-400 text-xs font-mono">Maula Ali, Kolkata • ID: City BR 11 / 03177724</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
